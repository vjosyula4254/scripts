/*jslint node: true */
const request = require("request-promise");
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupEnvCaches', 'Backup all EnvCache from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var bckdUpCachesCount = 0;

		var done = this.async();

		grunt.log.ok("Started Task : backupEnvCaches");
		try {
			//Get Token
			let token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			try {
				//Build Options to retrieve Environments
				var environmentsOptions = {
					'url': edgeUrl + "/v1/organizations/" + org + "/environments",
					'headers': {
						'Authorization': token,
					},
					resolveWithFullResponse: true
				};
				//Get Environments in a Org
				grunt.log.ok("Getting Environments in a Org using : " + environmentsOptions.url);
				let environmentsResponse = await request(environmentsOptions);

				//Process environmentsResponse
				if (environmentsResponse.statusCode == 200) {
					//Environments Retrieved sucessfully
					grunt.log.ok("Environments Retrieved : " + environmentsResponse.body);
					var environments = JSON.parse(environmentsResponse.body);

					// Check number of environments
					if (environments.length == 0) {
						// No Environments
						grunt.log.ok("No Environments found..exiting backupEnvCache");
						//done();
					} else {
						var totalCaches = 0;
						//Environments retrieved. Get Cache's for each Environment
						for (var envIndex = 0; envIndex < environments.length; envIndex++) {
							var cachesUrl = edgeUrl + "/v1/organizations/" + org + "/environments/" + environments[envIndex] + "/caches";
							grunt.log.ok("Env Cache URL: " + cachesUrl);
							var cachesOptions = {
								'url': cachesUrl,
								'headers': {
									'Authorization': token,
								},
								resolveWithFullResponse: true
							};

							grunt.log.ok("Getting Caches for an Environment using : " + cachesOptions.url);
							try {
								//Get Caches for an environment
								let cachesResponse = await request(cachesOptions);
								if (cachesResponse.statusCode == 200) {
									grunt.log.ok("Caches Retrieved for environment " + environments[envIndex] + " : " + cachesResponse.body);
									var caches = JSON.parse(cachesResponse.body);
									totalCaches += caches.length;


									//Get Cache Details for each Cache
									for (var cacheIndex = 0; cacheIndex < caches.length; cacheIndex++) {
										//Build Get Cache Details URL and options

										var cacheDetailsUrl = cachesUrl + "/" + caches[cacheIndex];
										var cacheDetailsOptions = {
											'url': cacheDetailsUrl,
											'headers': {
												'Authorization': token,
											},
											resolveWithFullResponse: true
										};
										grunt.log.ok("Getting Cache Details for the Cache " + caches[cacheIndex] + " using : " + cacheDetailsOptions.url);
										try {
											//Get Caches details for an Caches
											let cacheDetailResponse = await request(cacheDetailsOptions);

											//Process cacheDetailResponse 
											if (cacheDetailResponse.statusCode == 200) {
												//grunt.log.ok("Cache Details Retrieved : " + cacheDetailResponse.body);

												//Backup Cache details into the database
												var postDbUrl = dbUrl + "/edge/org/" + org + "/env/" + environments[envIndex] + "/conf/cache/version/" + version
												var postDbOptions = {
													'url': postDbUrl,
													'body': cacheDetailResponse.body,
													'method': 'POST',
													'headers': {
														'Content-Type': 'application/json',
														'Authorization': backupApiToken
													},
													resolveWithFullResponse: true

												};

												//Post the data to the Database
												try {
													grunt.log.ok("Backing up Cache Details using : " + postDbOptions.url);
													let backupApiResponse = await request(postDbOptions);
													grunt.log.ok("postdbResponse.statusCode : " + backupApiResponse.statusCode);
													if (backupApiResponse.statusCode == 200) {
														grunt.log.ok('Post the data to the Database Completed : ' + backupApiResponse.body);
														bckdUpCachesCount++;
													} else {
														//Recieved NON 200 status code while Backing up Cache Details into the database
														grunt.log.error("Recieved NON 200 status code while Backing up Cache Details, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
													}
												} catch (error) {
													//Error occurred while  Backingup Cache Details into the databse
													grunt.log.error("Error while Backing up Cache Details into the databse. " + error);
												}
											} else {
												//Recieved NON 200 status code while Getting Caches for an Environment
												grunt.log.error("Recieved NON 200 status code while retrieving Cache Details, statusCode : " + cacheDetailResponse.statusCode + " Error: " + cacheDetailResponse.error);
											}
										} catch (error) {
											//Error occured while retrieving Caches Details for an environment
											grunt.log.error("Error occured while retrieving Caches Details for an environment. " + error);
										}
									}
								} else {
									//Recieved NON 200 status code Getting Caches for an Environment
									grunt.log.error("Recieved NON 200 status code while retrieving Caches for an Environment, statusCode : " + cachesResponse.statusCode + " Error: " + cachesResponse.error);
								}
							} catch (error) {
								//Error occured while retrieving Caches for an environment
								grunt.log.error("Error occured while retrieving Caches for an environment. " + error);

							}
						}
					}
					grunt.log.ok("Backed up " + bckdUpCachesCount + " Caches out of " + totalCaches);
				} else {
					//Recieved NON 200 status code from Get Environments
					grunt.log.error("Error while getting environments, statusCode : " + environmentsResponse.statusCode + " Error: " + environmentsResponse.error);

				}

				//Backup Cache Completed
				grunt.log.ok("Completed Task : backupEnvCaches");
			} catch (error) {
				//Error while retrieving all Environments
				grunt.log.error("Error occured while retrieving all Environments. " + error);
			}

		} catch (error) {
			//Error while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
};