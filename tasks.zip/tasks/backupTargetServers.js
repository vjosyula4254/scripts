/*jslint node: true */
const request = require("request-promise");
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupTargetServers', 'Backup all EnvTargetServer from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var bckdUpTargetServersCount = 0;
		var done = this.async();

		grunt.log.ok("Started Task : backupTargetServers");

		try {
			//Get Token
			let token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			try {
				//Build Options to retrieve Environments
				var environmentsOptions = {
					'url': edgeUrl + "/v1/organizations/" + org + "/environments",
					'headers': {
						'Authorization': token,
					},
					resolveWithFullResponse: true
				};
				//Get Environments in a Org
				grunt.log.ok("Getting Environments in a Org using : " + environmentsOptions.url);
				let environmentsResponse = await request(environmentsOptions);
				//Process environmentsResponse
				if (environmentsResponse.statusCode == 200) {
					//Environments Retrieved sucessfully
					grunt.log.ok("Environments Retrieved : " + environmentsResponse.body);
					var environments = JSON.parse(environmentsResponse.body);

					// Check number of environments
					if (environments.length == 0) {
						// No Environments
						grunt.log.ok("No Environments found. exiting backupTargetServers");
					} else {
						var totalTargetServers = 0;
						//Environments retrieved. Get target servers for each Environment
						for (var envIndex = 0; envIndex < environments.length; envIndex++) {
							//Build Get Target Server URL and options
							var targetserversUrl = edgeUrl + "/v1/organizations/" + org + "/environments/" + environments[envIndex] + "/targetservers";
							grunt.log.ok("Env TargetServer URL: " + targetserversUrl);
							var targetserversOptions = {
								'url': targetserversUrl,
								'headers': {
									'Authorization': token,
								},
								resolveWithFullResponse: true
							};

							grunt.log.ok("Getting Target Servers for an Environment using : " + targetserversOptions.url);
							try {
								//Get Target Servers for an environment
								let targetserversResponse = await request(targetserversOptions);
								if (targetserversResponse.statusCode == 200) {
									//grunt.log.ok("Target Servers Retrieved for environment " + environments[envIndex] + " : " + targetserversResponse.body);
									var targetservers = JSON.parse(targetserversResponse.body);
									totalTargetServers += targetservers.length;
									//Get Target Server Details for each Target Server
									for (var targetserverIndex = 0; targetserverIndex < targetservers.length; targetserverIndex++) {
										//Build Get Target Server Details URL and options
										var targetserverDetailsUrl = targetserversUrl + "/" + targetservers[targetserverIndex];
										var targetserverDetailsOptions = {
											'url': targetserverDetailsUrl,
											'headers': {
												'Authorization': token,
											},
											resolveWithFullResponse: true
										};
										grunt.log.ok("Getting Target Server Details for the TargetServer : " + targetservers[targetserverIndex] + " using : " + targetserverDetailsOptions.url);
										try {

											//Get Target Servers details for an Target Server
											let targetserverDetailsResponse = await request(targetserverDetailsOptions);

											//Process targetserverDetailsResponse 
											if (targetserverDetailsResponse.statusCode == 200) {
												//Backup Target Server details into the database
												var postdbUrl = dbUrl + "/edge/org/" + org + "/env/" + environments[envIndex] + "/conf/target-server/version/" + version
												var postdbOptions = {
													'url': postdbUrl,
													'body': targetserverDetailsResponse.body,
													'method': 'POST',
													'headers': {
														'Content-Type': 'application/json',
														'Authorization': backupApiToken
													},
													resolveWithFullResponse: true
												};
												//Post the data to the Database
												try {
													grunt.log.ok("Backingup Target Server Details using : " + postdbOptions.url);
													let backupApiResponse = await request(postdbOptions);
													if (backupApiResponse.statusCode == 200) {
														grunt.log.ok('Post the data to the Database Completed.');
														bckdUpTargetServersCount++;
													} else {
														//Recieved NON 200 status code while Backing up Target Server Details into the database
														grunt.log.error("Recieved NON 200 status code while Backing up Target Server Details, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
													}
												} catch (error) {
													//Error occurred while  Backing up Target Server Details into the databse
													grunt.log.error("Error while Backing up Target Server  Details into the databse. " + error);
												}
											} else {
												//Recieved NON 200 status code while retrieving Target Servers for an Environment
												grunt.log.error("Recieved NON 200 status code while retrieving Target Server  Details, statusCode : " + targetserverDetailsResponse.statusCode + " Error: " + targetserverDetailsResponse.error);
											}
										} catch (error) {
											//Error occured while retrieving Target Servers Details for an environment
											grunt.log.error("Error occured while retrieving Target Servers Details for an environment. " + error);
										}
									}
								} else {
									//Recieved NON 200 status code retrieving Target Servers for an Environment
									grunt.log.error("Recieved NON 200 status code while retrieving Target Servers for an Environment, statusCode : " + targetserversResponse.statusCode + " Error: " + targetserversResponse.error);
								}
							} catch (error) {
								//Error occured while retrieving Target Servers for an environment
								grunt.log.error("Error occured while retrieving Target Servers for an environment. " + error);
							}
						}
					}
					grunt.log.ok("Backed up " + bckdUpTargetServersCount + " Target Servers out of " + totalTargetServers);
				} else {
					//Recieved NON 200 status code while retrieving all Environments
					grunt.log.error("Recieved NON 200 status code while retrieving all environments, statusCode : " + environmentsResponse.statusCode + " Error: " + environmentsResponse.error);
				}
				//Backup Target Server Completed
				grunt.log.ok("Completed Task : backupTargetServers");
			} catch (error) {
				//Error while retrieving all Environments
				grunt.log.error("Error occured while retrieving all Environments. " + error);
			}
		} catch (error) {
			//Error occured while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
}