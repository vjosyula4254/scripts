const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverCompanies', 'Restore all companies to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var recoverCompanyCount = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverCompanies");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
					//console.log(backupApiToken);
				}
				var companyIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company/version/" + version;
				var companyEdgeOptions = {
					'url': companyIdUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				//Get Company Ids from the database.
				//grunt.log.ok("Getting Company Ids using : " + companyEdgeOptions.url);
				await request(companyEdgeOptions)
					.then(async function (companyIdResponse) {
						if (companyIdResponse.statusCode == 200) {
							var companyIds = JSON.parse(companyIdResponse.body);
							if (companyIds.length == 0) {
								grunt.log.error("No Company Ids found in the backup Database.");
								//done();
							} else {
								//Found CompanyIds for the backup
								for (var companyIdIndex = 0; companyIdIndex < companyIds.length; companyIdIndex++) {
									//Found Company Ids for the backup
									var companyDetailsUrl = apigee.db.url + "/edge/conf/id/" + companyIds[companyIdIndex];
									//Call company details
									if (companyIds.length > 2048) {
										grunt.log.ok("SKIPPING Company, URL too long: ");
										recoverCompanyCount++;
									} else {
										//build Company Details Url
										companyEdgeOptions.url = companyDetailsUrl;
										//Get Company Details
										//grunt.log.ok("Getting Chache Details using : " + companyEdgeOptions.url);
										await request(companyEdgeOptions)
											.then(async function (companyDetailsResponse) {
												if (companyDetailsResponse.statusCode == 200) {
													//Get Company Name and Company Environment
													var companyDetails = JSON.parse(companyDetailsResponse.body);
													var b64EncdCompanyPayload = companyDetails["base64-encoded-payload"];
													var buff = Buffer.from(b64EncdCompanyPayload, 'base64');
													let b64DecdCompanyPayload = JSON.parse(buff.toString('utf-8'));

													var companyName = b64DecdCompanyPayload["name"];;

													// Build Options to create Company in the Edge
													var companyEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies";
													//grunt.log.ok("Post Edge URL:" + companyEdgeUrl);
													var companyEdgeOptions = {
														'url': companyEdgeUrl,
														'body': JSON.stringify(b64DecdCompanyPayload),
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true
													};
													//Create Company into Edge
													//grunt.log.ok(" Creating Company into Edge using Url : " + companyEdgeOptions.url);
													await request(companyEdgeOptions)
														.then(async function (companyEdgeResponse) {
															if (companyEdgeResponse.statusCode == 201) {
																recoverCompanyCount++;
																grunt.log.ok("companyName : " + companyName + " have been Recovered.");
															}
														})
														.catch((error) => {
															//Error occurred while Creating Company into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Company to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Company to Edge. " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Company as API Company already exists. " + error);
															} else {
																grunt.log.error("Unknown Error occurred while adding Company. " + error);
															}
														})

												} else {
													//Non 200 HTTP status code received.
													grunt.log.error("Non 200 HTTP status code  received retrieving Company Details. " + error);
												}
											})
											.catch((error) => {
												grunt.log.error("Error occurred while retrieveing Company Details. " + error);
											})
									}
								}
								grunt.log.ok(recoverCompanyCount + " out of " + companyIds.length + " Companies have been recovered.");
								grunt.log.ok("Completed Task : recoverCompanies");

							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Non 200 HTTP status code  received retrieving Company Ids. " + error);
						}
					})
					.catch((error) => {
						grunt.log.error("Error occurred while retrieveing Company Ids. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})
	});

	grunt.registerMultiTask('recoverCompany', 'Restore single company to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
		var resourceName = grunt.option('res_name') || "cahche-name";
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverCompany");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
					//console.log(backupApiToken);
				}

				var companyIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company/version/" + version + "/name/" + resourceName;
				var companyEdgeOptions = {
					'url': companyIdUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				//Get Company Ids from the database.
				//grunt.log.ok("Getting Company Ids using : " + companyEdgeOptions.url);
				await request(companyEdgeOptions)
					.then(async function (companyIdResponse) {
						if (companyIdResponse.statusCode == 200) {
							var companyId = companyIdResponse.body;
							//grunt.log.ok("companyId :" + companyId);
							if (companyId.length == 0) {
								grunt.log.error("No Company Id found in the backup Database.");
								//done();
							} else {
								//Found CompanyIds for the backup
								var companyDetailsUrl = apigee.db.url + "/edge/conf/id/" + companyId;
								//Call company details
								if (companyId.length > 2048) {
									grunt.log.ok("SKIPPING Company, URL too long: ");
								} else {
									//build Company Details Url
									companyEdgeOptions.url = companyDetailsUrl;
									//Get Company Details
									//grunt.log.ok("Getting Chache Details using : " + companyEdgeOptions.url);
									await request(companyEdgeOptions)
										.then(async function (companyDetailsResponse) {
											if (companyDetailsResponse.statusCode == 200) {
												//Get Company Name and Company Environment
												var companyDetails = JSON.parse(companyDetailsResponse.body);
												var b64EncdCompanyPayload = companyDetails["base64-encoded-payload"];
												var buff = Buffer.from(b64EncdCompanyPayload, 'base64');
												let b64DecdCompanyPayload = JSON.parse(buff.toString('utf-8'));

												var companyName = b64DecdCompanyPayload["name"];;
												//grunt.log.ok("companyName : " + companyName);
												// Build Options to create Company in the Edge
												var companyEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies";
												//grunt.log.ok("Post Edge URL:" + companyEdgeUrl);
												var companyEdgeOptions = {
													'url': companyEdgeUrl,
													'body': JSON.stringify(b64DecdCompanyPayload),
													'method': 'POST',
													'headers': {
														'Content-Type': 'application/json',
														'Authorization': token
													},
													resolveWithFullResponse: true
												};
												//Create Company into Edge
												//grunt.log.ok(" Creating Company into Edge using Url : " + companyEdgeOptions.url);
												await request(companyEdgeOptions)
													.then(async function (companyEdgeResponse) {
														if (companyEdgeResponse.statusCode == 201) {
															grunt.log.ok("companyName : " + companyName + " has been recovered.");
															grunt.log.ok("Completed Task : recoverCompany");
															Promise.resolve(companyEdgeResponse.body);
														}
													})
													.catch((error) => {
														//Error occurred while Creating Company into Edge
														if (error.statusCode == 401) {
															grunt.log.error("Error occurred while adding Company to Edge due to invalid credentials. " + error);
														} else if (error.statusCode == 400) {
															grunt.log.error("Error occurred while adding Company to Edge. " + error);
														} else if (error.statusCode == 409) {
															grunt.log.error("Error occurred while adding Company as API Company already exists. " + error);
														} else {
															grunt.log.error("Unknown Error occurred while adding Company. " + error);
														}
													})
												//}
											} else {
												//Non 200 HTTP status code received.
												grunt.log.error("Non 200 HTTP status code  received retrieving Company Details. " + error);
											}
										})
										.catch((error) => {
											grunt.log.error("Error occurred while retrieveing Company Details. " + error);
										})
								}

							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Non 200 HTTP status code  received retrieving Company Ids. " + error);
						}
					})
					.catch((error) => {
						grunt.log.error("Error occurred while retrieveing Company Ids. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})

	});
};