const request = require("request-promise");
//var request = require('request');
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
    'use strict';
    grunt.registerMultiTask('recoverTargetServers', 'Restore all env-targetServer to org ', async function () {
        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverTargetServerCnt = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;


        var done = this.async();
        grunt.log.ok("Started Task : recoverTargetServers");

        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //grunt.log.ok("Token : " + token);
                //Build Options to get the Target Servers from the DB.
                var targetServersIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/target-server/version/" + version;
                var targetServersIdOptions = {
                    'url': targetServersIdUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                //Get Target Server Ids from the database.
                grunt.log.ok("Getting Target Server Ids using : " + targetServersIdOptions.url);
                await request(targetServersIdOptions)
                    .then(async function (targetServersIdResponse) {
                        if (targetServersIdResponse.statusCode == 200) {
                            var targetServerIds = JSON.parse(targetServersIdResponse.body);
                            if (targetServerIds.length == 0) {
                                grunt.log.error("No Target Servers found in the backup Database.");
                                //done();
                            } else {
                                //Found target servers for the backup
                                for (var targetServerIndex = 0; targetServerIndex < targetServerIds.length; targetServerIndex++) {
                                    var targetServerDetailsUrl = apigee.db.url + "/edge/conf/id/" + targetServerIds[targetServerIndex];
                                    if (targetServerIds.length > 2048) {
                                        grunt.log.error("SKIPPING Target Server, URL too long: ");
                                        recoverTargetServerCnt++;
                                    } else {
                                        //build Target Server Details Url
                                        targetServersIdOptions.url = targetServerDetailsUrl;
                                        //Get Target Server Details
                                        await request(targetServersIdOptions)
                                            .then(async function (targetServerDetailsResponse) {
                                                if (targetServerDetailsResponse.statusCode == 200) {
                                                    // Create Target Server into Edge
                                                    var targetServerDetails = JSON.parse(targetServerDetailsResponse.body);
                                                    var targetServerEnv = targetServerDetails["env-name"];
                                                    var b64EncdPayload = targetServerDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdPayload, 'base64');
                                                    let b64DecdtPayload = buff.toString('utf-8');

                                                    // Build Options to create Product in the Edge
                                                    var targetServerEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + targetServerEnv + "/targetservers";
                                                    var targetServerEdgeOptions = {
                                                        'url': targetServerEdgeUrl,
                                                        'body': b64DecdtPayload,
                                                        'method': 'POST',
                                                        'headers': {
                                                            'Content-Type': 'application/json',
                                                            'Authorization': token
                                                        },
                                                        resolveWithFullResponse: true
                                                    };

                                                    var targetServerBody = JSON.parse(b64DecdtPayload)
 
                                                    //Create Target Server into Edge
                                                    //grunt.log.ok(" Creating Target Server into Edge using Url : " + targetServerEdgeOptions.url);
                                                    await request(targetServerEdgeOptions)
                                                        .then(async function (targetServerEdgeResponse) {
                                                            if (targetServerEdgeResponse.statusCode == 201) {
                                                                grunt.log.ok("Target Server Recovered " + targetServerBody.name);
                                                                recoverTargetServerCnt++;
                                                                //resolve(targetServerEdgeResponse.body);
                                                            }
                                                        })
                                                        .catch((error) => {
                                                            //Error occurred while Creating Target Server into Edge
                                                            if (error.statusCode == 401) {
                                                                grunt.log.error("Error occurred while adding Target Server to Edge due to invalid credentials. " + error);
                                                            } else if (error.statusCode == 400) {
                                                                grunt.log.error("Error occurred while adding Target Server to Edge. " + error);
                                                            } else if (error.statusCode == 409) {
                                                                grunt.log.error("Error occurred while adding Target Server as API Target Server already exists. " + error);
                                                            } else {
                                                                grunt.log.error("Unknown Error occurred while adding Target Server. " + error);
                                                            }
                                                        })

                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving Target Server Details. " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing Target Server Ids. " + error);
                                            })
                                    }
                                }
                                grunt.log.ok(recoverTargetServerCnt + " out of " + targetServerIds.length + " Target Servers have been recovered.");
                                grunt.log.ok("Completed Task : recoverTargetServers");
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving Target Server Ids. " + error);
                        }

                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing Target Server Ids. " + error);
                    })

            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            });

    });


    grunt.registerMultiTask('recoverTargetServer', 'Restore single env-targetServer to org ', async function () {
        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var resourceName = grunt.option('res_name') || "Azure-pMDM";
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverTargetServerCnt = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;
        var done = this.async();

        grunt.log.ok("Started Task : recoverTargetServer");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //grunt.log.ok("Token : " + token);
                //Build Options to get the Target Servers from the DB.
                var targetServersIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/target-server/version/" + version;
                var targetServersIdOptions = {
                    'url': targetServersIdUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true

                };
                //Get Target Server Ids from the database.
                grunt.log.ok("Getting Target Server Ids using : " + targetServersIdOptions.url);
                await request(targetServersIdOptions)
                    .then(async function (targetServersIdResponse) {
                        if (targetServersIdResponse.statusCode == 200) {
                            var targetServerIds = JSON.parse(targetServersIdResponse.body);
                            if (targetServerIds.length == 0) {
                                grunt.log.error("No Target Servers found in the backup Database.");
                                //done();
                            } else {
                                //Found target servers for the backup
                                for (var targetServerIndex = 0; targetServerIndex < targetServerIds.length; targetServerIndex++) {
                                    var targetServerDetailsUrl = apigee.db.url + "/edge/conf/id/" + targetServerIds[targetServerIndex];
                                    if (targetServerIds.length > 2048) {
                                        grunt.log.error("SKIPPING Target server, URL too long: ");
                                        recoverTargetServerCnt++;
                                    } else {
                                        //build Target Server Details Url
                                        targetServersIdOptions.url = targetServerDetailsUrl;
                                        //Get Target Server Details
                                        //grunt.log.ok("Getting Target Server Details using : " + targetServersIdOptions.url);
                                        await request(targetServersIdOptions)
                                            .then(async function (targetServerDetailsResponse) {
                                                if (targetServerDetailsResponse.statusCode == 200) {
                                                    // Create Target Server into Edge
                                                    var targetServerDetails = JSON.parse(targetServerDetailsResponse.body);
                                                    var b64EncdPayload = targetServerDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdPayload, 'base64');
                                                    let b64DecdPayload = JSON.parse(buff.toString('utf-8'));

                                                    var targetServerName = b64DecdPayload["name"];
                                                    var targetServerEnv = targetServerDetails['env-name'];

                                                    //grunt.log.ok("b64DecdtargetServerDetails: " + JSON.stringify(b64DecdPayload) + ", targetServerName : " + targetServerName + ",  targetServerEnv : " + targetServerEnv);
                                                    if (targetServerName == resourceName && targetServerEnv == env) {
                                                        // Build Options to create Product in the Edge
                                                        var targetServerEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + env + "/targetservers";
                                                        var targetServerEdgeOptions = {
                                                            'url': targetServerEdgeUrl,
                                                            'body': JSON.stringify(b64DecdPayload),
                                                            'method': 'POST',
                                                            'headers': {
                                                                'Content-Type': 'application/json',
                                                                'Authorization': token
                                                            },
                                                            resolveWithFullResponse: true
                                                        };
                                                        //Create Target Server into Edge
                                                        grunt.log.ok(" Creating Target Server into Edge using Url : " + targetServerEdgeOptions.url);
                                                        await request(targetServerEdgeOptions)
                                                            .then(async function (targetServerEdgeResponse) {
                                                                if (targetServerEdgeResponse.statusCode == 201) {
                                                                    grunt.log.ok("Target Server: " + targetServerName + " in environment: " + env + " has been recovered.");
                                                                    recoverTargetServerCnt++;
                                                                    Promise.resolve(targetServerEdgeResponse.body);
                                                                }
                                                            })
                                                            .catch((error) => {
                                                                //Error occurred while Creating Target Server into Edge
                                                                if (error.statusCode == 401) {
                                                                    grunt.log.error("Error occurred while adding Target Server to Edge due to invalid credentials. Error : " + error);
                                                                } else if (error.statusCode == 400) {
                                                                    grunt.log.error("Error occurred while adding Target Server to Edge.  Error : " + error);
                                                                } else if (error.statusCode == 409) {
                                                                    grunt.log.error("Error occurred while adding Target Server as API Target Server already exists. Error: " + error);
                                                                } else {
                                                                    grunt.log.error("Unknown Error occurred while adding Target Server. Error: " + error);
                                                                }
                                                            })

                                                    }

                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving Target Server Details. Error: " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing Target Server Ids. Error: " + error);
                                            })
                                    }
                                }
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving Target Server Ids. Error: " + error);
                        }

                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing Target Server Ids. Error: " + error);
                    })

            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. Error :" + error);
                Promise.resolve(error);
            })
    })

}