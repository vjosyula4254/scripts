const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverCompanyApps', 'Restore all Company Apps to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var recoveredCompanyAppsCount = 0;
		var companyAppsCount = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;
		var done = this.async();
		grunt.log.ok("Started Task : recoverCompanyApps");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
					//console.log(backupApiToken);
				}

				//Build Options to get Company App Ids from the DB.
				var companyAppIdsUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company-app/version/" + version;
				var companyAppIdsOptions = {
					'url': companyAppIdsUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				//Get Company App Ids from the database.
				grunt.log.ok("Getting Company App Ids using : " + companyAppIdsOptions.url);
				await request(companyAppIdsOptions)
					.then(async function (companyAppIdsResponse) {
						if (companyAppIdsResponse.statusCode == 200) {
							var companyAppIds = JSON.parse(companyAppIdsResponse.body);
							if (companyAppIds.length == 0) {
								grunt.log.error("No Company App Ids found in the backup Database.");
								//done();
							} else {
								//Found Company App Ids for the backup
								for (var companyAppIdIndex = 0; companyAppIdIndex < companyAppIds.length; companyAppIdIndex++) {
									//Found companyApp Ids for the backup
									var companyAppDetailsUrl = dbUrl + "/edge/conf/id/" + companyAppIds[companyAppIdIndex];
									//If URL is bigger than 2048 then skip it.
									if (companyAppDetailsUrl.length > 2048) {
										grunt.log.write("SKIPPING Company App as URL too long: " + companyAppDetailsUrl);
										companyAppsCount++;
									} else {
										//build Company App Details Url
										companyAppIdsOptions.url = companyAppDetailsUrl;
										//Get Company App Details
										grunt.log.ok("Getting Company App Details using : " + companyAppIdsOptions.url);
										await request(companyAppIdsOptions)
											.then(async function (companyAppDetailsResponse) {
												if (companyAppDetailsResponse.statusCode == 200) {
													//Get Company App Name
													var companyAppDetails = JSON.parse(companyAppDetailsResponse.body);
													var b64EncdCompanyAppPayload = companyAppDetails["base64-encoded-payload"];
													var buff = Buffer.from(b64EncdCompanyAppPayload, 'base64');
													let b64DecdCompanyAppPayload = JSON.parse(buff.toString('utf-8'));
													b64DecdCompanyAppPayload["name"] = b64DecdCompanyAppPayload["name"].split(":")[1];
													var companyAppName = b64DecdCompanyAppPayload["name"];;
													var companyName = b64DecdCompanyAppPayload["companyName"];
													grunt.log.ok("companyAppName : " + companyAppName + ", companyName: " + companyName);
													// Create company app object, remove read only properties
													let companyAppObject = new Object();
													companyAppObject.attributes = b64DecdCompanyAppPayload.attributes;
													companyAppObject.name = b64DecdCompanyAppPayload.name;
													companyAppObject.callbackUrl = b64DecdCompanyAppPayload.callbackUrl;

													// Build Options to create Company App in the Edge
													var companyAppEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + companyName + "/apps"
													var companyAppEdgeOptions = {
														'url': companyAppEdgeUrl,
														'body': JSON.stringify(companyAppObject),
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true
													};
													//Create CompanyApp into Edge
													grunt.log.ok(" Creating CompanyApp into Edge using Url : " + companyAppEdgeOptions.url);
													await request(companyAppEdgeOptions)
														.then(async function (companyAppEdgeResponse) {
															if (companyAppEdgeResponse.statusCode == 201) {
																// Build Options to update the key and secret
																var companyAppKeysEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + companyName + "/apps/" + companyAppName + "/keys/";
																var companyAppEdgeResponsePayload = JSON.parse(companyAppEdgeResponse.body);
																companyAppEdgeResponsePayload.credentials.forEach(async credential => {
																	let ckey = new Object();
																	ckey.consumerKey = credential.consumerKey;
																	//Build options to delete keys
																	var companyAppDeleteKeysOptions = {
																		'url': companyAppKeysEdgeUrl + ckey.consumerKey,
																		'method': 'DELETE',
																		'headers': {
																			'Content-Type': 'application/json',
																			'Authorization': token
																		},
																		resolveWithFullResponse: true
																	};

																	await request(companyAppDeleteKeysOptions)
																		.then(async function (companyAppDeleteKeysResponse) {
																			if (companyAppDeleteKeysResponse.statusCode == 200) {
																				grunt.log.ok("Deleted key for Company App : " + companyAppName);
																			}

																		}).catch((error) => {
																			grunt.log.error("Error occurred while deleting key for company app : " + companyAppName + " " + error);
																		})
																});

																b64DecdCompanyAppPayload.credentials.forEach(async credential => {
																	let productList = [];
																	let keySecret = new Object();
																	keySecret.consumerKey = credential.consumerKey;
																	keySecret.consumerSecret = credential.consumerSecret;

																	credential.apiProducts.forEach(product => {
																		productList.push(product.apiproduct);
																	});
																	let productPayload = new Object();
																	productPayload.apiProducts = productList;
																	var companyAppKeysEdgeOptions = {
																		'url': companyAppKeysEdgeUrl + "create",
																		'body': JSON.stringify(keySecret),
																		'method': 'POST',
																		'headers': {
																			'Content-Type': 'application/json',
																			'Authorization': token
																		},
																		resolveWithFullResponse: true
																	};
																	await request(companyAppKeysEdgeOptions)
																		.then(async function (companyAppKeysEdgeResponse) {
																			if (companyAppKeysEdgeResponse.statusCode == 201) {

																				var ckeyProductsEdgeOptions = {
																					'url': companyAppKeysEdgeUrl + keySecret.consumerKey,
																					'body': JSON.stringify(productPayload),
																					'method': 'POST',
																					'headers': {
																						'Content-Type': 'application/json',
																						'Authorization': token
																					},
																					resolveWithFullResponse: true
																				};

																				await request(ckeyProductsEdgeOptions)
																					.then(async function (ckeyProductsEdgeResponse) {
																						if (ckeyProductsEdgeResponse.statusCode == 200) {
																							// grunt.log.ok("Products has been attached to the Company App: " + companyAppName);
																							Promise.resolve(ckeyProductsEdgeResponse.body);
																						}
																					}).catch((error) => {
																						grunt.log.error("Error occurred while adding products for company app key " + error);
																					})
																			}
																		}).catch((error) => {
																			grunt.log.error("Error occurred while updating key and secret for Company App " + error);

																		})
																	// grunt.log.ok("Comapny App : " + companyAppName + " have been Recovered.");
																});
																recoveredCompanyAppsCount++;
																grunt.log.ok("Company App: " + companyAppName + " has been recovered for the Company : " + companyName);
															}
														})
														.catch((error) => {
															//Error occurred while Creating Company App into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Company App to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Company App to Edge. " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Company App as API Company App already exists. " + error);
															} else {
																grunt.log.error("Unknown Error occurred while adding Company App. " + error);
															}
														})

												} else {
													//Non 200 HTTP status code received.
													grunt.log.error("Non 200 HTTP status code  received retrieving Company App Details. " + error);
												}
											})
											.catch((error) => {
												grunt.log.error("Error occurred while retrieveing Company App Details. " + error);
											})
									}
								}
								grunt.log.ok(recoveredCompanyAppsCount + " out of " + companyAppIds.length + " Company Apps have been recovered.");
								grunt.log.ok("Completed Task : recoverCompanyApps");

							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Non 200 HTTP status code  received retrieving Company App Ids. " + error);
						}
					})
					.catch((error) => {
						grunt.log.error("Error occurred while retrieveing Company App Ids. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})

	});


	grunt.registerMultiTask('recoverCompanyApp', 'Restore single Company App to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var resourceName = grunt.option('res_name');
		var resourceNames = resourceName.split(":");
		var resourceCompanyName = resourceNames[0];
		var resourceCompanyAppName = resourceNames[1];

		var fromOrg = grunt.option('apigee_fromorg') || org;

		var companyAppCount = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;
		var done = this.async();
		grunt.log.ok("Started Task : recoverCompanyApp");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
					//console.log(backupApiToken);
				}

				//Build Options to get Company App Ids from the DB.
				var companyAppIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company-app/version/" + version + "/name/" + resourceName;
				var companyAppIdOptions = {
					'url': companyAppIdUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				//Get Company App Id from the database.
				grunt.log.ok("Retrieving ID from the Database for the Company App using URL: " + companyAppIdUrl);
				await request(companyAppIdOptions)
					.then(async function (companyAppIdResponse) {
						if (companyAppIdResponse.statusCode == 200) {
							var companyAppId = companyAppIdResponse.body;
							if (companyAppId.length == 0) {
								grunt.log.error("No Company App Ids found in the backup Database.");
								//done();
							} else {
								//Found Company App Id to recover
								var companyAppDetailsUrl = apigee.db.url + "/edge/conf/id/" + companyAppId;
								//If URL is bigger than 2048 then skip it.
								if (companyAppDetailsUrl.length > 2048) {
									grunt.log.write("SKIPPING Company App as URL too long: " + companyAppDetailsUrl);
									companyAppCount++;
								} else {
									//build Company App Details Url
									companyAppIdOptions.url = companyAppDetailsUrl;
									//Get Company App Details
									grunt.log.ok("Getting Company App Details using : " + companyAppIdOptions.url);
									await request(companyAppIdOptions)
										.then(async function (companyAppDetailsResponse) {
											if (companyAppDetailsResponse.statusCode == 200) {
												//Get Company App Name
												var companyAppDetails = JSON.parse(companyAppDetailsResponse.body);
												var b64EncdCompanyAppPayload = companyAppDetails["base64-encoded-payload"];
												var buff = Buffer.from(b64EncdCompanyAppPayload, 'base64');
												let b64DecdCompanyAppPayload = JSON.parse(buff.toString('utf-8'));
												b64DecdCompanyAppPayload["name"] = b64DecdCompanyAppPayload["name"].split(":")[1];
												var companyAppName = b64DecdCompanyAppPayload["name"];;
												var companyName = b64DecdCompanyAppPayload["companyName"];
												grunt.log.ok("companyAppName : " + companyAppName + ", companyName: " + companyName);
												//grunt.log.ok("resourceCompanyAppName : " + resourceCompanyAppName + ", resourceCompanyName: " + resourceCompanyName);

												let companyAppObject = new Object();
												companyAppObject.attributes = b64DecdCompanyAppPayload.attributes;
												companyAppObject.name = b64DecdCompanyAppPayload.name;
												companyAppObject.callbackUrl = b64DecdCompanyAppPayload.callbackUrl;

												if (companyAppName == resourceCompanyAppName && companyName == resourceCompanyName) {
													// Build Options to create Company App in the Edge
													var companyAppEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + companyName + "/apps"
													var companyAppEdgeOptions = {
														'url': companyAppEdgeUrl,
														'body': JSON.stringify(companyAppObject),
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true
													};
													//Create CompanyApp into Edge
													grunt.log.ok(" Creating CompanyApp into Edge using Url : " + companyAppEdgeOptions.url);
													await request(companyAppEdgeOptions)
														.then(async function (companyAppEdgeResponse) {
															if (companyAppEdgeResponse.statusCode == 201) {
																var companyAppKeysEdgeUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + companyName + "/apps/" + companyAppName + "/keys/";
																var companyAppEdgeResponsePayload = JSON.parse(companyAppEdgeResponse.body);
																companyAppEdgeResponsePayload.credentials.forEach(async credential => {
																	let ckey = new Object();
																	ckey.consumerKey = credential.consumerKey;
																	//Build options to delete keys
																	var companyAppDeleteKeysOptions = {
																		'url': companyAppKeysEdgeUrl + ckey.consumerKey,
																		'method': 'DELETE',
																		'headers': {
																			'Content-Type': 'application/json',
																			'Authorization': token
																		},
																		resolveWithFullResponse: true
																	};

																	await request(companyAppDeleteKeysOptions)
																		.then(async function (companyAppDeleteKeysResponse) {
																			if (companyAppDeleteKeysResponse.statusCode == 200) {
																				grunt.log.ok("Deleted key for Company App : " + companyAppName);
																			}

																		}).catch((error) => {
																			grunt.log.error("Error occurred while deleting key for company app : " + companyAppName + " " + error);
																		})
																});

																// Build Options to update the key and secret
																b64DecdCompanyAppPayload.credentials.forEach(async credential => {
																	let productList = [];
																	let keySecret = new Object();
																	keySecret.consumerKey = credential.consumerKey;
																	keySecret.consumerSecret = credential.consumerSecret;

																	credential.apiProducts.forEach(product => {
																		productList.push(product.apiproduct);
																	});
																	let productPayload = new Object();
																	productPayload.apiProducts = productList;

																	var companyAppKeysEdgeOptions = {
																		'url': companyAppKeysEdgeUrl + "create",
																		'body': JSON.stringify(keySecret),
																		'method': 'POST',
																		'headers': {
																			'Content-Type': 'application/json',
																			'Authorization': token
																		},
																		resolveWithFullResponse: true
																	};
																	await request(companyAppKeysEdgeOptions)
																		.then(async function (companyAppKeysEdgeResponse) {
																			if (companyAppKeysEdgeResponse.statusCode == 201) {
																				grunt.log.ok("Company App: " + companyAppName + " has been recovered for the Company : " + companyName);
																				grunt.log.ok("Completed Task : recoverCompanyApp");

																				var ckeyProductsEdgeOptions = {
																					'url': companyAppKeysEdgeUrl + keySecret.consumerKey,
																					'body': JSON.stringify(productPayload),
																					'method': 'POST',
																					'headers': {
																						'Content-Type': 'application/json',
																						'Authorization': token
																					},
																					resolveWithFullResponse: true
																				};

																				await request(ckeyProductsEdgeOptions)
																					.then(async function (ckeyProductsEdgeResponse) {
																						if (ckeyProductsEdgeResponse.statusCode == 200) {
																							// grunt.log.ok("Products have been attached to the Company App: " + companyAppName);
																							Promise.resolve(ckeyProductsEdgeResponse.body);
																						}
																					}).catch((error) => {
																						grunt.log.error("Error occurred while adding products for company app key " + error);
																					})
																			}
																		}).catch((error) => {
																			grunt.log.error("Error occurred while updating key and secret for Company App " + error);

																		})
																});

															}
														})
														.catch((error) => {
															//Error occurred while Creating Company App into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Company App to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Company App to Edge.  " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Company App as API Company App already exists. " + error);
															} else {
																grunt.log.error("Unknown Error occurred while adding Company App. " + error);
															}
														})
												} else {
													//Company App not found.
													grunt.log.error("Company App: " + resourceCompanyAppName + ", & Company: " + resourceCompanyName + "  - This resource combination NOT found . ");
												}

											} else {
												//Non 200 HTTP status code received.
												grunt.log.error("Non 200 HTTP status code  received retrieving Company App Details. " + error);
											}
										})
										.catch((error) => {
											grunt.log.error("Error occurred while retrieveing Company App Details. " + error);
										})
								}
							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Non 200 HTTP status code  received retrieving Company App Ids. " + error);
						}
					})
					.catch((error) => {
						grunt.log.error("Error occurred while retrieveing Company App Ids. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})

	});


}