var request = require('request');

module.exports.call = async function call(options) {
    // options.maxAttempts = 5; // (default) try 5 times 
    // options.retryDelay = 100; // (default) wait for 5s before trying again
    // options.retrySrategy = request.RetryStrategies.HTTPOrNetworkError; // (default) retry on 5xx or network errors
    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            if (error) {
                return reject(error);
            }
            if (response.statusCode === 200 || response.statusCode === 201) {
                return resolve(body);
            } else {
                return reject(response.body);
            }
        });
    });
}