/*jslint node: true */
const request = require("request-promise");
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupEnvKvms', 'Backup all KVMs from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var bckdUpKVMsCount = 0;
		var invalidKvmCnt = 0;

		var done = this.async();

		grunt.log.ok("Started Task : backupEnvKvms");

		try {
			//Get Token
			let token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			try {
				//Build Options to retrieve Environments
				var environmentsOptions = {
					'url': edgeUrl + "/v1/organizations/" + org + "/environments",
					'headers': {
						'Authorization': token,
					},
					resolveWithFullResponse: true
				};
				//Get Environments in a Org
				grunt.log.ok("Getting Environments in a Org using : " + environmentsOptions.url);
				let environmentsResponse = await request(environmentsOptions);
				//Process environmentsResponse
				if (environmentsResponse.statusCode == 200) {
					//Environments Retrieved sucessfully
					grunt.log.ok("Environments Retrieved : " + environmentsResponse.body);
					var environments = JSON.parse(environmentsResponse.body);

					// Check number of environments
					if (environments.length == 0) {
						// No Environments
						grunt.log.ok("No Environments found. exiting backupEnvKVM");
					} else {
						//Environments retrieved. Get KVMs for each Environment
						var totalKvms = 0
						for (var envIndex = 0; envIndex < environments.length; envIndex++) {
							//Build Get KVms URL and options
							var kvmsUrl = edgeUrl + "/v1/organizations/" + org + "/environments/" + environments[envIndex] + "/keyvaluemaps";
							var kvmsOptions = {
								'url': kvmsUrl,
								'headers': {
									'Authorization': token,
								},
								resolveWithFullResponse: true
							};

							grunt.log.ok("Getting KVMs for an Environment using : " + kvmsOptions.url);
							try {
								//Get KVMs for an environment
								let kvmsResponse = await request(kvmsOptions);
								if (kvmsResponse.statusCode == 200) {
									//grunt.log.ok("KVMs Retrieved for environment : " + environments[envIndex]);
									var kvms = JSON.parse(kvmsResponse.body);
									totalKvms += kvms.length;
									//Get KVM Details for each KVM
									for (var kvmIndex = 0; kvmIndex < kvms.length; kvmIndex++) {
										if (kvms[kvmIndex].trim() != "") {
											//Build Get KVM Details URL and options
											var kvmDetailsUrl = kvmsUrl + "/" + kvms[kvmIndex];
											var kvmDetailsOptions = {
												'url': kvmDetailsUrl,
												'headers': {
													'Authorization': token,
												},
												resolveWithFullResponse: true
											};
											grunt.log.ok("Getting KVM Details for the KVM " + kvms[kvmIndex] + " using : " + kvmDetailsOptions.url);
											try {

												//Get KVM details for an KVM
												let kvmDetailResponse = await request(kvmDetailsOptions);

												//Process kvmDetailResponse 
												if (kvmDetailResponse.statusCode == 200) {
													//Backup KVM details into the database
													var postDbUrl = dbUrl + "/edge/org/" + org + "/env/" + environments[envIndex] + "/conf/kvm/version/" + version
													var postDbOptions = {
														'url': postDbUrl,
														'body': kvmDetailResponse.body,
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': backupApiToken
														},
														resolveWithFullResponse: true
													};
													//Post the data to the Database
													try {
														grunt.log.ok("Backing up KVM Details using : " + postDbOptions.url);
														let backupApiResponse = await request(postDbOptions);
														if (backupApiResponse.statusCode == 200) {
															grunt.log.ok('Post the data to the Database Completed.');
															bckdUpKVMsCount++;
														}
														else {
															//Recieved NON 200 status code while Backing up KVM Details into the database
															grunt.log.error("Recieved NON 200 status code while Backing up KVM Details into the database, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
														}
													}
													catch (error) {
														//Error occurred while  Backingup KVM Details into the database
														grunt.log.error("Error while Backingup KVM Details into the databse. " + error);
													}
												}
												else {
													//Recieved NON 200 status code while retrieving KVMs for an Environment
													grunt.log.error("Recieved NON 200 status code while retrieving KVM Details, statusCode : " + kvmDetailResponse.statusCode + " Error: " + kvmDetailResponse.error);
												}
											}
											catch (error) {
												//Error occurred while retrieving KVM Details 
												grunt.log.error("Error while retrieving KVM Details . Error :" + error);
											}
										}
										else {
											//Errro empty KVM
											invalidKvmCnt++;
											grunt.log.error("Found Empty KVM Name skipping the KVM. KVM Name :" + kvms[kvmIndex]);

										}
									}

								}
								else {
									//Recieved NON 200 status code while retrieving KVMs for an Environment
									grunt.log.error("Recieved NON 200 status code while retrieving KVMs for an Environment, statusCode : " + kvmsResponse.statusCode + " Error: " + kvmsResponse.error);
								}
							}
							catch (error) {
								//Error occured while KVMs Environments
								grunt.log.error("Error occured while retrieving KVMs. " + error);
							}
						}
					}
					grunt.log.ok(`Backed up ${bckdUpKVMsCount} KVMs out of ${totalKvms - invalidKvmCnt}`);
				}
				else {
					//Recieved NON 200 status code while retrieving all Environments
					grunt.log.error("Recieved NON 200 status code while retrieving all environments, statusCode : " + environmentsResponse.statusCode + " Error: " + environmentsResponse.error);
				}
				//Backup KVM Completed
				grunt.log.ok("Completed Task : backupEnvKvms");
			}
			catch (error) {
				//Error while retrieving all Environments
				grunt.log.error("Error occured while retrieving all Environments. " + error);
			}
		}
		catch (error) {
			//Error occured while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
}