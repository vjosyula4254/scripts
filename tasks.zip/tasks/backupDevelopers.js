/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupDevelopers', 'Backup all developers from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var devCount = 0;
		var totalBckdUpDevelopers = 0;
		var done = this.async();

		var backupDeveloper = async function (developerDetails) {
			//Build Options for adding Developer into the database
			var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/developer/version/" + version
			var postDbOptions = {
				'url': postDbUrl,
				'body': JSON.stringify(developerDetails),
				'method': 'POST',
				'headers': {
					'Content-Type': 'application/json',
					'Authorization': backupApiToken
				},
				resolveWithFullResponse: true
			};
			//Post the data to the Database
			try {
				grunt.log.ok("Backing up Developer using : " + postDbOptions.url);
				let backupApiResponse = await request(postDbOptions);
				if (backupApiResponse.statusCode == 200) {
					grunt.log.ok('Posting of the Data to the Database Completed : ' + backupApiResponse.body);
					totalBckdUpDevelopers++;
				} else {
					//Recieved NON 200 status code while Backing up Developer Details into the database
					grunt.log.error("Error while Backingup Developer Details into the databse. statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
				}
			} catch (error) {
				//Error occurred while Backingup Developer Details into the database
				grunt.log.error("Error while Backing up Developer Details into the databse. status code :" + error + " error : " + error.error);
			}
			grunt.log.ok('Backed up ' + totalBckdUpDevelopers + ' Developers out of ' + devCount + " Developers");
		}

		var backupAllDevelopers = async function (startDeveloperEmail) {
			var apigeeDevelopersUrlWithStartkey = edgeUrl + "/v1/organizations/" + org + "/developers?expand=true";
			if (startDeveloperEmail) {
				apigeeDevelopersUrlWithStartkey += "&startKey=" + encodeURIComponent(startDeveloperEmail);
			}
			//Build Options to get All Developers
			var developersOptions = {
				'url': apigeeDevelopersUrlWithStartkey,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};
			//Get All Developers
			grunt.log.ok("Getting All Developers using : " + apigeeDevelopersUrlWithStartkey);
			try {
				let apiDevelopersRespose = await request(developersOptions);
				if (apiDevelopersRespose.statusCode = 200) {
					//Developers retrieved
					var developerDetailsBody = JSON.parse(apiDevelopersRespose.body);
					let developers = developerDetailsBody.developer;
					if (developers.length > 0) {
						if (startDeveloperEmail) {
							/*	APIGEE SaaS MGMT APIs returns only 1000 developers in one management call
								this is to check if backupAllDevelopers called recursively (for more than 1000 developers),
								if that's the case then startDeveloperEmail will have the developer which we provided
								as a startKey, so we should not process the first developer from this list. Remove first Developer.
							*/
							//Remove first developer from the list.
							grunt.log.ok("removing " + developers[0] + "form the list");
							developers.shift();
						}
						// Process remaining Developers
						if (developers.length > 0) {
							devCount += developers.length
							for (var developerIndex = 0; developerIndex < developers.length; developerIndex++) {
								grunt.log.ok("Backing up Developer Info for the Developer: " + developers[developerIndex].email);
								await backupDeveloper(developers[developerIndex]);
							}
							/* 	APIGEE cloud returns only 1000 developers in one management call
								If number of Developers are >=1000   then there is possibility that there
								are more developers. Make a recursive call to get all the developers 
								until all developers are retrieved.
							*/
							if (developers.length >= 999) {
								var lastDeveloper = developers[developers.length - 1].email;
								await backupAllDevelopers(lastDeveloper);
							}
						}

					} else {
						grunt.log.ok('No App Developers Found.  Developers : ' + JSON.stringify(apiDevelopersRespose));
					}
				} else {
					//Received non 200 HTTP call from retrieve Developer
					grunt.log.error("Error while retrieving Developers. Status Code : " + error.statusCode + ", Error Message : " + error.error);
				}
			} catch (error) {
				//Error occured while retrieving Developer
				grunt.log.error("Error occured while retrieving All Developers. StatusCode: " + error);
			}
		}
		// Start backupDevelopers Task
		grunt.log.ok("Started Task : backupDevelopers");
		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			//Backup all Developers
			await backupAllDevelopers(null);
		} catch (error) {
			//Error occured while doing backupdevelopers Task
			grunt.log.error("Error occured while doing backupdevelopers Task. " + error);
		}
	});
};