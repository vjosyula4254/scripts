const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverProducts', 'Restore all products to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var done_count = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverProducts");
		var recoverProdcutCount = 0;
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				//grunt.log.ok("Token : " + token);
				//Build Options to get the product Id from the DB.
				var getProductsUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/product/version/" + version;

				var getProductsOptions = {
					'url': getProductsUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true

				};
				//Get All Products from the database.
				grunt.log.ok("Getting Product Id using : " + getProductsOptions.url);
				await request(getProductsOptions)
					.then(async function (productResponse) {
						if (productResponse.statusCode == 200) {
							//	grunt.log.write("PRODUCTS_id: " + body);
							var products = JSON.parse(productResponse.body);
							if (products.length == 0) {
								grunt.log.error("Product NOT found in the backup.");
								//done();
							} else {
								for (var productIndex = 0; productIndex < products.length; productIndex++) {
									//Build Get Product URL
									var getProductUrl = dbUrl + "/edge/conf/id/" + products[productIndex];
									if (getProductUrl > 2048) {
										grunt.log.error("SKIPPING Product, URL too long, URL : " + getProductUrl);
										done_count++;
									} else {
										//Get Product Details
										getProductsOptions.url = getProductUrl;
										grunt.log.ok("Getting Product detail using url : " + getProductsOptions.url);

										await request(getProductsOptions)
											.then(async function (productDetailsResponse) {

												if (productDetailsResponse.statusCode == 200) {
													//grunt.log.ok("PRODUCT :" + productDetailsResponse.body);
													var productDetails = JSON.parse(productDetailsResponse.body);
													var b64EncddProductDetails = productDetails["base64-encoded-payload"];
													var buff = Buffer.from(b64EncddProductDetails, 'base64');
													let b64DecddProductDetails = buff.toString('utf-8');

													// Build Options to create Product in the Edge
													var apiProductsUrl = edgeUrl + "v1/organizations/" + org + "/apiproducts";
													var apiProductsOptions = {
														'url': apiProductsUrl,
														'body': b64DecddProductDetails,
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true

													};
													//Create Product into Edge
													grunt.log.ok(" Creating product into Edge using Url : " + apiProductsOptions.url);
													//grunt.log.ok(" Creating product into Edge using Body : " + apiProductsOptions.body);
													await request(apiProductsOptions)
														.then((productDetailsResponse) => {
															if (productDetailsResponse.statusCode == 201) {
																recoverProdcutCount++;
																grunt.log.ok("Product Recovered");
																resolve(productDetailsResponse.body);
															}
														})
														.catch((error) => {
															//Error occurred while Creating Product into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Product to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Product to Edge due to the Error : " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Product as API products exists. " + error);
															}
														})


												}

											})
											.catch((error) => {
												//Error occured while getting product Details from the Database
												grunt.log.error("Error occured while getting product Details from the Database. " + error);
											})

									}
								}
								grunt.log.ok(recoverProdcutCount + " out of " + products.length + " products have been recovered.");
								grunt.log.ok("Complated Task : recoverProducts");
							}
						}
					})
					.catch((error) => {
						//Error occurred while getting products List from the Database
						grunt.log.error("Error occurred while getting products List from the Database. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});

	})



	grunt.registerMultiTask('recoverProduct', 'Restore single product to org ', async function () {

		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var resourceName = grunt.option('res_name') || "fuseInventory"
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverProduct");
		await OauthService.getToken()
			.then(async function (token) {
				//Token received
				//grunt.log.ok("Token : " + token);
				return (token);
			})
			//Get product Id from the DB.
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				//grunt.log.ok("Token : " + token);
				//Build Options to get the product Id from the DB.
				var getProductUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/product/version/" + version + "/name/" + resourceName;
				var getProductOptions = {
					'url': getProductUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				}
				//Get product backup Id from the Database
				grunt.log.ok("Getting Product Id using : " + getProductOptions.url);
				await request(getProductOptions)
					.then(async function (productResponse) {
						if (productResponse.statusCode == 200) {
							var productId = productResponse.body;
							if (productId.length == 0) {
								grunt.log.error("Product NOT found in the backup.");
							} else {
								//Product Id found ing the backup.
								grunt.log.ok("Product Found. Id : " + productId);

								//Get Product Details
								getProductOptions.url = dbUrl + "/edge/conf/id/" + productId;
								grunt.log.ok("Getting Product Details using :" + getProductOptions.url)
								await request(getProductOptions)
									.then(async function (productDetailsResponse) {

										if (productDetailsResponse.statusCode == 200) {
											//grunt.log.ok("PRODUCT :" + productDetailsResponse.body);
											var productDetails = JSON.parse(productDetailsResponse.body);
											var b64EncddProductDetails = productDetails["base64-encoded-payload"];
											var buff = Buffer.from(b64EncddProductDetails, 'base64');
											let b64DecddProductDetails = buff.toString('utf-8');

											// Build Options to create Product in the Edge
											var apiProductsUrl = edgeUrl + "v1/organizations/" + org + "/apiproducts";
											var apiProductsOptions = {
												'url': apiProductsUrl,
												'body': b64DecddProductDetails,
												'method': 'POST',
												'headers': {
													'Content-Type': 'application/json',
													'Authorization': token
												},
												resolveWithFullResponse: true

											};
											var dbResourceName = JSON.parse(b64DecddProductDetails).name;
											if (JSON.stringify(dbResourceName) === JSON.stringify(resourceName)) {
												//Create Product
												grunt.log.ok(" Creating product into Edge using Url : " + apiProductsOptions.url);
												//grunt.log.ok(" Creating product into Edge using Body : " + apiProductsOptions.body);
												await request(apiProductsOptions)
													.then((productDetailsResponse) => {
														if (productDetailsResponse.statusCode == 201) {
															grunt.log.ok("Product : " + resourceName + " has been recovered.");
															grunt.log.ok("Completed Task : recoverProduct");
															resolve(productDetailsResponse.body);
														}
													}).catch((error) => {
														if (error.statusCode == 401) {
															grunt.log.error("Error occurred while adding Product to Edge due to invalid credentials. " + error);
														} else if (error.statusCode == 400) {
															grunt.log.error("Error occurred while adding Product to Edge due to the Error : " + error);
														} else if (error.statusCode == 409) {
															grunt.log.error("Error occurred while adding Product as API products exists. " + error);
														}
													})

											}
										}

									})
									.catch((error) => {
										//Error occured while getting product Details from the Database
										grunt.log.error("Error occured while getting product Details from the Database. " + error);
									})

							}
						}
					})
			})
			.catch((error) => {
				//Error occured while getting product backup Id from the Database
				grunt.log.error("Error occured while getting product backup Id from the Database. " + error);

			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});
	});
}; //module closing