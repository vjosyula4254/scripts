/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

var userroles;
module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupRoles', 'Backup all user roles ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var roleCount = 0;
		var bckdUpRolesCount = 0;

		var done = this.async();

		grunt.log.ok("Started Task : backupRoles");

		try {
			//Get token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}


			let rolesUrl = edgeUrl + "/v1/organizations/" + org + "/userroles";
			var rolesOptions = {
				'url': rolesUrl,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};

			try {
				//Get All User Roles
				let userRolesResponse = await request(rolesOptions);
				if (userRolesResponse.statusCode == 200) {
					userroles = JSON.parse(userRolesResponse.body);

					if (userroles.length == 0) {
						grunt.log.ok("No User Roles");
						done();
					}
					for (var userrolesIndex = 0; userrolesIndex < userroles.length; userrolesIndex++) {
						var userrolesUrl = rolesUrl + "/" + userroles[userrolesIndex];

						//Call user roles details
						// An Edge bug allows user roles to be created with very long names which cannot be used in URLs.
						if (userrolesUrl.length > 1024) {
							grunt.log.ok("USER ROLES URL: " + userrolesUrl.length + " " + userrolesUrl);
							grunt.log.ok("SKIPPING USER ROLE, URL too long: ");
							roleCount++;
						} else {
							//Call user role details
							try {
								rolesOptions.url = userrolesUrl;
								let userRolesDetailsResponse = await request(rolesOptions);
								if (userRolesDetailsResponse.statusCode == 200) {

									//Backup Roles details into the database
									var postdbUrl = dbUrl + "/edge/org/" + org + "/conf/role/version/" + version;
									var postdbOptions = {
										'url': postdbUrl,
										'body': userRolesDetailsResponse.body,
										'method': 'POST',
										'headers': {
											'Content-Type': 'application/json',
											'Authorization': backupApiToken
										},
										resolveWithFullResponse: true
									};
									//Post the data to the Database
									try {
										grunt.log.ok("Backing up Roles Details using : " + postdbUrl);
										let backupApiResponse = await request(postdbOptions);
										grunt.log.ok("backupApiResponse.statusCode : " + backupApiResponse.statusCode);
										if (backupApiResponse.statusCode == 200) {
											roleCount++;
											bckdUpRolesCount++;
											grunt.log.ok('Post the data to the Database Completed : ' + backupApiResponse.body);
										}
									} catch (error) {
										roleCount++
										grunt.log.error("Error while inserting into the DB. status code :" + error.statusCode + " error : " + error);
									}
									if (roleCount == userroles.length) {
										grunt.log.ok('Backed up ' + bckdUpRolesCount + ' Roles out of ' + userroles.length + ' Roles ');
										grunt.log.ok("Completed Task : backupRoles");
									}
								} else {
									//Recieved NON 200 status code while retrieving all user Roles
									grunt.log.error("Recieved NON 200 status code while retrieving user role, statusCode : " + userRolesDetailsResponse.statusCode + " Error: " + userRolesDetailsResponse.error);
								}
							} catch (error) {
								roleCount++;
								grunt.log.error(`Error while retrieving user role details from apigee for role : ${userroles[userrolesIndex]} , error : ${error}`);
							}
						}
					}
				} else {
					//Recieved NON 200 status code while retrieving all Roles
					grunt.log.error("Recieved NON 200 status code while retrieving all roles, statusCode : " + userRolesResponse.statusCode + " Error: " + userRolesResponse.error);

				}
			} catch (error) {
				//Error while retrieving all Roles
				grunt.log.error("Error occured while retrieving all Roles. " + error);

			}
		} catch (error) {
			//Error while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
}