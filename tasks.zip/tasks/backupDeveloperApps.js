/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

const DEVELOPER_APP_NAME_DELIMITER = ":";
module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupDeveloperApps', 'Backup all apps from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var doneCount = 0;
		var devCount = 0;
		var totalDevAppsCount = 0;
		var bckdUpDeveloperAppsCount = 0;
		var done = this.async();

		var apigeeDevelopersUrl = edgeUrl + "/v1/organizations/" + org + "/developers";

		var backupDeveloperApp = async function (developerEmail) {
			var apigeeDeveloperAppDetailsUrl = apigeeDevelopersUrl + "/" + developerEmail + "/apps?expand=true";

			var appDetailsOptions = {
				'url': apigeeDeveloperAppDetailsUrl,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};
			try {
				var apiDeveloperAppDetailsResponse = await request(appDetailsOptions); //{
				if (apiDeveloperAppDetailsResponse.statusCode == 200) {
					var developerAppDetailsBody = JSON.parse(apiDeveloperAppDetailsResponse.body);
					var developerApps = developerAppDetailsBody.app;
					if (developerApps.length > 0) {
						totalDevAppsCount += developerApps.length;
						var totalAppsForDeveloper = 0;
						for (var j = 0; j < developerApps.length; j++) {
							var developerApp = developerApps[j];
							/*  Changing the Developer App Name to DeveloperEmail:DeveloperAppName before storing into the Database, 
								to handle the scenario of same Developer App names for multiple Developers. In recoverDeveloperApp job
								the Developer App Name will get reverted back to just Developer App Name before posting to Edge
							*/
							developerApp['name'] = developerEmail + DEVELOPER_APP_NAME_DELIMITER + developerApp.name;

							//Build Options for adding Developer Apps into the database
							var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/developer-app/version/" + version
							var postDbOptions = {
								'url': postDbUrl,
								'body': JSON.stringify(developerApp),
								'method': 'POST',
								'headers': {
									'Content-Type': 'application/json',
									'Authorization': backupApiToken
								},
								resolveWithFullResponse: true
							};
							//Post the data to the Database
							try {
								grunt.log.ok("Backing up Developer Apps using : " + postDbOptions.url);
								let backupApiResponse = await request(postDbOptions);
								if (backupApiResponse.statusCode == 200) {
									grunt.log.ok('Posting of the Data to the Database Completed : ' + backupApiResponse.body);
									totalAppsForDeveloper++;
									bckdUpDeveloperAppsCount++;
								} else {
									//Recieved NON 200 status code while Backing up Developer App Details into the database
									grunt.log.error("Error while Backingup Developer App Details into the databse. statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
								}
							} catch (error) {
								//Error occurred while Backingup Developer App Details into the database
								grunt.log.error("Error while Backing up Developer App Details into the databse. status code :" + error + " error : " + error.error);
							}

						};
						grunt.log.ok('Backed up ' + totalAppsForDeveloper + ' Developer App(s) for Developer: ' + developerEmail);
					} else {
						//No Apps Found for the Developer
						grunt.log.ok("No Apps Found for the Developer: " + developerEmail);
					}
				} else {
					//Recieved NON 200 status code retrieving App Developers
					grunt.log.error("Recieved NON 200 status code while retrieving Developer Apps. StatusCode: " + apiDeveloperAppDetailsResponse.statusCode + ", Error : " + apiDeveloperAppDetailsResponse.body);
				}
			} catch (error) {
				//Error occured while retrieving Developer App
				grunt.log.error("Error occured while retrieving Developer App. StatusCode: " + error);
			}
			doneCount++;
			if (doneCount == devCount) {
				grunt.log.ok('Backed Up ' + bckdUpDeveloperAppsCount + ' Developer App(s) out of ' + totalDevAppsCount + ' Developer Apps');
				grunt.log.ok("Completed Task : backupDeveloperApps");
			}
		}

		var backupAllDeveloperApps = async function (startDeveloperEmail) {
			var apigeeDevelopersUrlWithStartkey = apigeeDevelopersUrl;
			if (startDeveloperEmail) {
				apigeeDevelopersUrlWithStartkey += "?startKey=" + encodeURIComponent(startDeveloperEmail);
			}
			//Build Options to get All Developers
			var developersOptions = {
				'url': apigeeDevelopersUrlWithStartkey,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};
			//Get All Developers
			grunt.log.ok("Getting All Developers using : " + apigeeDevelopersUrlWithStartkey);
			try {
				let apiDevelopersRespose = await request(developersOptions);
				if (apiDevelopersRespose.statusCode = 200) {
					//Developers retrieved
					var developers = JSON.parse(apiDevelopersRespose.body);
					if (developers.length > 0) {
						if (startDeveloperEmail) {
							/*	APIGEE SaaS MGMT APIs returns only 1000 developers in one management call
								this is to check if backupAllDevelopers called recursively (for more than 1000 developers),
								if that's the case then startDeveloperEmail will have the developer which we provided
								as a startKey, so we should not process the first developer from this list. Remove first Developer.
							*/
							//Remove first developer from the list.
							grunt.log.ok("removing " + developers[0] + "form the list");
							developers.shift();
						}
						// Process remaining Developers
						if (developers.length > 0) {
							devCount += developers.length

							for (var developerIndex = 0; developerIndex < developers.length; developerIndex++) {
								grunt.log.ok("Backing up All Developer Apps for the Developer Email: " + developers[developerIndex]);
								await backupDeveloperApp(developers[developerIndex]);
							}

							/* 	APIGEE cloud returns only 1000 developers in one management call
								If number of Developers are >=1000   then there is possibility that there
								are more developers. Make a recursive call to get all the developers 
								until all developers are retrieved.
							*/
							if (developers.length >= 999) {
								var lastDeveloper = developers[developers.length - 1];
								await backupAllDeveloperApps(lastDeveloper);
							}
						}

					} else {
						grunt.log.ok('No App Developers Found.  Developers : ' + JSON.stringify(apiDevelopersRespose));
					}
				} else {
					//Received non 200 HTTP call from retrieve Developer Apps
					grunt.log.error("Error while retrieving Developer Apps. Status Code : " + error.statusCode + ", Error Message : " + error.error);
				}
			} catch (error) {
				//Error occured while retrieving Developer Apps
				grunt.log.error("Error occured while retrieving All Developers. StatusCode: " + error);
			}
		}
		// Start backupDeveloperApps Task
		grunt.log.ok("Started Task : backupDeveloperApps");
		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			//Backup all DeveloperApps
			await backupAllDeveloperApps(null);
		} catch (error) {
			//Error occured while doing backupDeveloperApps Task
			grunt.log.error("Error occured while doing backupDeveloperApps Task. " + error);
		}
	});
};