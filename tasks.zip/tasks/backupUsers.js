/*jslint node: true */
const request = require("request-promise");
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

var userroles;
module.exports = function (grunt) {
    'use strict';
    grunt.registerTask('backupUsers', 'Backup all users for each role ', async function () {
        var org = grunt.option('apigee_org') || "ferguson-api";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

        var edgeUrl = apigee.from.url;
        var dbUrl = apigee.db.url;

        var userCount = 0;
        var bckdUpUserRolesCount = 0;
        var done = this.async();

        grunt.log.ok("Started Task : backupUsers");

        let userRolesUrl = edgeUrl + "/v1/organizations/" + org + "/userroles";

        try {
            // Get token
            let token = await OauthService.getToken();

            //Get Token for Backup API Service
            var backupApiToken = "";
            if (apigee.db.account) {
                backupApiToken = await backupApiTokenService.getBackupServiceToken();
                //console.log(backupApiToken);
            }

            try {
                //Build Options to retrieve Roles
                var userRolesOptions = {
                    'url': userRolesUrl,
                    'headers': {
                        'Authorization': token,
                    },
                    resolveWithFullResponse: true
                };

                // Get all user roles
                let userRolesResponse = await request(userRolesOptions);
                if (userRolesResponse.statusCode == 200) {
                    userroles = JSON.parse(userRolesResponse.body);

                    if (userroles.length == 0) {
                        grunt.log.ok("No User Roles found. Exiting backupUsers");
                        done();
                    }

                    userroles.forEach(async function (userrole) {
                        var usersUrl = userRolesOptions.url + "/" + userrole + "/users";
                        var usersOptions = {
                            'url': usersUrl,
                            'headers': {
                                'Authorization': token,
                            },
                            resolveWithFullResponse: true
                        }

                        // grunt.log.ok("Getting User Roles Details for : " + userrole + " using : " + usersOptions.url);

                        //Call user roles details
                        // An Edge bug allows user roles to be created with very long names which cannot be used in URLs.
                        if (usersOptions.url.length > 1024) {
                            grunt.log.ok("SKIPPING User Roles, URL too long: ");
                            userCount++;
                        } else {
                            try {
                                let userDetailResponse = await request(usersOptions);
                                if (userDetailResponse.statusCode == 200) {

                                    //grunt.log.ok('users:' + users);
                                    //construct json payload with role name 
                                    var userDetails = {}
                                    userDetails.role = userrole;
                                    userDetails.name = userrole;
                                    userDetails.users = JSON.parse(userDetailResponse.body);

                                    // grunt.log.ok("userDetails " + JSON.stringify(userDetails)) ;
                                    var userDetailsString = JSON.stringify(userDetails)

                                    //Backup Users details into the database
                                    var postdbUrl = dbUrl + "/edge/org/" + org + "/conf/user/version/" + version;
                                    var postdbOptions = {
                                        'url': postdbUrl,
                                        'body': userDetailsString,
                                        'method': 'POST',
                                        'headers': {
                                            'Content-Type': 'application/json',
                                            'Authorization': backupApiToken
                                        },
                                        resolveWithFullResponse: true
                                    };

                                    //Post the data to the Database
                                    try {
                                        let backupApiResponse = await request(postdbOptions);
                                        grunt.log.ok("Backing up Users Details using : " + postdbUrl);
                                        if (backupApiResponse.statusCode == 200) {
                                            grunt.log.ok('Post the data to the Database Completed. ');
                                            userCount++;
                                            bckdUpUserRolesCount++;
                                        }
                                    } catch (error) {
                                        userCount++;
                                        grunt.log.error("Error while inserting into the DB. status code :" + error.statusCode + " " + error);
                                    }

                                    if (userCount == userroles.length) {
                                        grunt.log.ok('Backed up ' + bckdUpUserRolesCount + ' Roles Users out of ' + userroles.length + ' Roles Users');

                                        //Backup Roles Users Completed
                                        grunt.log.ok("Completed Task : backupUsers");
                                    }

                                } else {
                                    //Recieved NON 200 status code while retrieving all users in Role
                                    grunt.log.error("Recieved NON 200 status code while retrieving all users in role, statusCode : " + userDetailResponse.statusCode + " Error: " + userDetailResponse.error);
                                }
                            } catch (error) {
                                userCount++;
                                grunt.log.error("Error occured while retrieving user role " + userrole + " details from apigee. " + error);
                            }
                        }
                        // End user roles details
                    });


                } else {
                    //Recieved NON 200 status code while retrieving all User Roles
                    grunt.log.error("Recieved NON 200 status code while retrieving all user roles, statusCode : " + userRolesResponse.statusCode + " Error: " + userRolesResponse.error);
                }

            } catch (error) {
                //Error occured while getting Roles
                grunt.log.error("Error occurred while retrieving all roles. " + error);
            }

        } catch (error) {
            //Error while getting Token
            grunt.log.error("Error occurred while getting Token. " + error);
        }

    });

};