const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverRoles', 'Restore all Roles to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var done_count = 0;
		var edgeUrl = apigee.to.url;
		var dbUrl = apigee.db.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverRoles");
		var recoverRoleCount = 0;
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {

				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}
				//grunt.log.ok("Token : " + token);
				//Build Options to get the role Id from the DB.
				var getRolesUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/role/version/" + version;

				var getRolesOptions = {
					'url': getRolesUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true

				};
				//Get All Roles from the database.
				grunt.log.ok("Getting Role Id using : " + getRolesOptions.url);
				await request(getRolesOptions)
					.then(async function (roleResponse) {
						if (roleResponse.statusCode == 200) {
							//	grunt.log.write("Roles_id: " + body);
							var Roles = JSON.parse(roleResponse.body);
							if (Roles.length == 0) {
								grunt.log.error("Role NOT found in the backup.");
								//done();
							} else {
								for (var roleIndex = 0; roleIndex < Roles.length; roleIndex++) {
									//Build Get Role URL
									var getRoleUrl = dbUrl + "/edge/conf/id/" + Roles[roleIndex];
									if (getRoleUrl > 2048) {
										grunt.log.error("SKIPPING Role, URL too long, URL : " + getRoleUrl);
										done_count++;
									} else {
										//Get Role Details
										getRolesOptions.url = getRoleUrl;
										grunt.log.ok("Getting Role detail using url : " + getRolesOptions.url);

										await request(getRolesOptions)
											.then(async function (roleDetailsResponse) {

												if (roleDetailsResponse.statusCode == 200) {
													//grunt.log.ok("ROLE :" + roleDetailsResponse.body);
													var roleDetails = JSON.parse(roleDetailsResponse.body);
													var b64EncddRoleDetails = roleDetails["base64-encoded-payload"];
													var buff = Buffer.from(b64EncddRoleDetails, 'base64');
													let b64DecddRoleDetails = buff.toString('utf-8');
													const roleString = '{"role" : [ ' + b64DecddRoleDetails + ']}';


													// Build Options to create Role in the Edge
													var rolesUrl = edgeUrl + "v1/organizations/" + org + "/userroles";
													var rolesOptions = {
														'url': rolesUrl,
														'body': roleString,
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true

													};
													//Create Role into Edge
													grunt.log.ok(" Creating role into Edge using Url : " + rolesOptions.url);
													//grunt.log.ok(" Creating role into Edge using Body : " + rolesOptions.body);
													await request(rolesOptions)
														.then((roleDetailsResponse) => {
															if (roleDetailsResponse.statusCode == 201) {
																recoverRoleCount++;
																grunt.log.ok("Role Recovered");
																resolve(roleDetailsResponse.body);
															}
														})
														.catch((error) => {
															//Error occurred while Creating Role into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Role to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Role to Edge due to the Error : " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Role as API Roles exists. " + error);
															} else {
																grunt.log.error("Error occurred while adding Role. " + error);
															}
														})
												}

											})
											.catch((error) => {
												//Error occured while getting role Details from the Database
												grunt.log.error("Error occured while getting role Details from the Database. " + error);
											})

									}
								}
								grunt.log.ok(recoverRoleCount + " out of " + Roles.length + " Roles have been recovered.");
								grunt.log.ok("Completed Task : recoverRoles");
							}
						}
					})
					.catch((error) => {
						//Error occurred while getting Roles List from the Database
						grunt.log.error("Error occurred while getting Roles List from the Database. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});

	})

	grunt.registerMultiTask('recoverRole', 'Restore single role to org ', async function () {

		// Proess grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var resourceName = grunt.option('res_name') || "Developer"
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverRole");
		await OauthService.getToken()
			.then(async function (token) {
				//Token received
				//grunt.log.ok("Token : " + token);
				return (token);
			})
			//Get role Id from the DB.
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				//Build Options to get the role Id from the DB.
				var getRoleUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/role/version/" + version + "/name/" + resourceName;
				var getRoleOptions = {
					'url': getRoleUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				}
				//Get role backup Id from the Database
				grunt.log.ok("Getting Role Id using : " + getRoleOptions.url);
				await request(getRoleOptions)
					.then(async function (roleResponse) {
						if (roleResponse.statusCode == 200) {
							var roleId = roleResponse.body;
							if (roleId.length == 0) {
								grunt.log.error("Role NOT found in the backup.");
							} else {
								//Role Id found ing the backup.
								grunt.log.ok("Role Found. Id : " + roleId);

								//Get Role Details
								getRoleOptions.url = dbUrl + "/edge/conf/id/" + roleId;
								grunt.log.ok("Getting Role Details using :" + getRoleOptions.url)
								await request(getRoleOptions)
									.then(async function (roleDetailsResponse) {

										if (roleDetailsResponse.statusCode == 200) {
											//grunt.log.ok("ROLE :" + roleDetailsResponse.body);
											var roleDetails = JSON.parse(roleDetailsResponse.body);
											var b64EncddRoleDetails = roleDetails["base64-encoded-payload"];
											var buff = Buffer.from(b64EncddRoleDetails, 'base64');
											let b64DecddRoleDetails = buff.toString('utf-8');
											const roleString = '{"role" : [ ' + b64DecddRoleDetails + ']}';


											// Build Options to create Role in the Edge
											var rolesUrl = edgeUrl + "v1/organizations/" + org + "/userroles";
											var rolesOptions = {
												'url': rolesUrl,
												'body': roleString,
												'method': 'POST',
												'headers': {
													'Content-Type': 'application/json',
													'Authorization': token
												},
												resolveWithFullResponse: true

											};
											var dbResourceName = JSON.parse(b64DecddRoleDetails).name;
											if (JSON.stringify(dbResourceName) === JSON.stringify(resourceName)) {
												//Create Role
												grunt.log.ok(" Creating role into Edge using Url : " + rolesOptions.url);
												//grunt.log.ok(" Creating role into Edge using Body : " + rolesOptions.body);
												await request(rolesOptions)
													.then((roleDetailsResponse) => {
														if (roleDetailsResponse.statusCode == 201) {
															grunt.log.ok("Role : " + resourceName + " has been recovered.");
															grunt.log.ok("Completed Task : recoverRole");
															resolve(roleDetailsResponse.body);
														}
													}).catch((error) => {
														if (error.statusCode == 401) {
															grunt.log.error("Error occurred while adding Role to Edge due to invalid credentials. " + error);
														} else if (error.statusCode == 400) {
															grunt.log.error("Error occurred while adding Role to Edge due to the Error : " + error);
														} else if (error.statusCode == 409) {
															grunt.log.error("Error occurred while adding Role as API Roles exists. " + error);
														}
													})

											}
										}

									})
									.catch((error) => {
										//Error occured while getting role Details from the Database
										grunt.log.error("Error occured while getting role Details from the Database. " + error);
									})

							}
						}
					})
			})
			.catch((error) => {
				//Error occured while getting role backup Id from the Database
				grunt.log.error("Error occured while getting role backup Id from the Database. " + error);

			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});
	});
}; //module closing