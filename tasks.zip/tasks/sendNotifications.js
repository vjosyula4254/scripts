/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev_secure';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');
const nodemailer = require("nodemailer");

module.exports = function (grunt) {
    'use strict';
    grunt.registerTask('sendNotifications', 'Send notifications for Tasks ', async function () {
        var org = grunt.option('apigee_org') || "ferguson-api";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

        var dbUrl = apigee.db.url;

        var done = this.async();

        grunt.log.ok("Started Task : sendNotifications");
        try {

            //Get Token for Backup API Service
            var backupApiToken = "";
            if (apigee.db.account) {
                backupApiToken = await backupApiTokenService.getBackupServiceToken();
                //console.log(backupApiToken);
            }

            var auditSummaryDbUrl = dbUrl + "/edge/audit/summary/" + version;
            var auditSummaryDbOptions = {
                'url': auditSummaryDbUrl,
                'method': 'GET',
                'headers': {
                    'Content-Type': 'application/json',
                    'Authorization': backupApiToken
                },
                resolveWithFullResponse: true
            };
            //Post the data to the Database
            try {
                grunt.log.ok("Getting Audit summary details using : " + auditSummaryDbUrl);
                let auditSummaryResponse = await request(auditSummaryDbOptions);
                if (auditSummaryResponse.statusCode == 200) {
                    //grunt.log.ok('Audit summary : ' + auditSummaryResponse.body);
                    var auditSummaryList = JSON.parse(auditSummaryResponse.body);
                    var errorObj = [];
                    auditSummaryList.forEach(auditSummary => {
                        if (auditSummary["failure"] > 0) {
                            errorObj.push(auditSummary);
                        }
                    })
                    grunt.log.ok("errorObj.length : " + errorObj.length);
                    grunt.log.ok("errorObj : " + JSON.stringify(errorObj, null, 4));

                    if (errorObj.length > 0) {
                        let transporter = nodemailer.createTransport({
                            host: apigee.notifications.smtphost,
                            port: apigee.notifications.smtpport,
                            secure: true, // true for 465, false for other ports
                            auth: {
                                user: apigee.notifications.smtpuser, // generated ethereal user
                                pass: apigee.notifications.smtpcred, // generated ethereal password
                            },
                        });

                        // send mail with defined transport object
                        let info = await transporter.sendMail({
                            from: apigee.notifications.fromemail, // sender address
                            to: apigee.notifications.toemaillist, // list of receivers
                            subject: "Backup Job Error notification- Version # " + version + " Org : " + org, // Subject line
                            text: "Error occured while backuping up following conf-types: \n" + JSON.stringify(errorObj, null, 4), // plain text body
                            //html: JSON.stringify(errorObj), // html body
                        });
                    }
                    grunt.log.ok("Completed Task : sendNotifications");

                } else {
                    //Recieved NON 200 status code while Backing up Company Details into the database
                    grunt.log.error("Error occurred while getting audit summary: " + auditSummaryResponse);
                }
            } catch (error) {
                //Error occurred while getting audit summary
                grunt.log.error("Error occurred while sending nofication. error : " + error);
            }
        }
        catch (error) {
            //Error occurred while getting token 
            grunt.log.error("Error occurred while getting token " + " error : " + error);
        }
    });
}