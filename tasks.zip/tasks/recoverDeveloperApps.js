const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const DEVELOPER_APP_NAME_DELIMITER = ":";
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverDeveloperApps', 'Restore all Developer Apps to org ', async function () {
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var fromOrg = 'ferguson-api'
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var recoveredDeveloperAppsCount = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverDeveloperApps");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				var developerAppsIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/developer-app/version/" + version;
				var developerAppsIdOptions = {
					'url': developerAppsIdUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				grunt.log.ok("Retrieving Developer Ids from the Database");
				await request(developerAppsIdOptions)
					.then(async function (developerAppsIdResponse) {
						if (developerAppsIdResponse.statusCode == 200) {
							var developerAppIds = JSON.parse(developerAppsIdResponse.body);
							if (developerAppIds.length == 0) {
								grunt.log.error("No Developer App Ids were found in the backup Database.");
							} else {
								//Found Developer Ids for backup
								for (var developerAppIdIndex = 0; developerAppIdIndex < developerAppIds.length; developerAppIdIndex++) {
									var developerAppDetailsDbUrl = dbUrl + "/edge/conf/id/" + developerAppIds[developerAppIdIndex];
									//Build Developer App Details Url
									developerAppsIdOptions.url = developerAppDetailsDbUrl;
									//Call Developer App details
									grunt.log.ok("Retrieving Developer App Details from the Database Using the URL: " + developerAppDetailsDbUrl);
									await request(developerAppsIdOptions)
										.then(async function (developerAppDetailsResponse) {
											if (developerAppDetailsResponse.statusCode == 200) {
												var developerAppDetails = JSON.parse(developerAppDetailsResponse.body);
												var b64EncdDeveloperAppPayload = developerAppDetails["base64-encoded-payload"];
												var buff = new Buffer(b64EncdDeveloperAppPayload, 'base64');
												let b64DecdDeveloperAppPayload = JSON.parse(buff.toString('utf-8'));
												var developerAppNDevEmail = b64DecdDeveloperAppPayload['name'].split(DEVELOPER_APP_NAME_DELIMITER);
												if (developerAppNDevEmail.length != 2) {
													grunt.log.error("SKIPPING. Name doesn't contain both Developer App Name and Developer Email");
													return;
												}
												var developerEmail = developerAppNDevEmail[0];
												var developerAppName = developerAppNDevEmail[1];
												/* Replacing the Developer App Name with just Developer App Name before posting to Edge,
													because in backupDeveloperApp job the name has been set to DeveloperEmail:DeveloperAppName combination 
													to avoid same App name for multiple developers scenario
												*/
												b64DecdDeveloperAppPayload['name'] = developerAppName;
												// Create developer app object, remove read only properties
												let developerAppObject = new Object();
												developerAppObject.attributes = b64DecdDeveloperAppPayload.attributes;
												developerAppObject.name = b64DecdDeveloperAppPayload.name;
												developerAppObject.callbackUrl = b64DecdDeveloperAppPayload.callbackUrl;
												// Build Options to create Developer App in Edge
												var developerAppEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers/" + developerEmail + "/apps";
												var developerAppPostEdgeOptions = {
													'url': developerAppEdgeUrl,
													'body': JSON.stringify(developerAppObject),
													'method': 'POST',
													'headers': {
														'Content-Type': 'application/json',
														'Authorization': token
													},
													resolveWithFullResponse: true
												};
												//Create Developer App in Edge
												grunt.log.ok("Posting Developer App Details to Edge Using URL:" + developerAppEdgeUrl);
												await request(developerAppPostEdgeOptions)
													.then(async function (developerAppEdgeResponse) {
														if (developerAppEdgeResponse.statusCode == 201) {
															// Build Options to update the key and secret
															var developerAppKeysEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers/" + developerEmail + "/apps/" + developerAppName + "/keys/";

															var developerAppEdgeResponsePayload = JSON.parse(developerAppEdgeResponse.body);
															developerAppEdgeResponsePayload.credentials.forEach(async credential => {
																let ckey = new Object();
																ckey.consumerKey = credential.consumerKey;
																//Build options to delete keys
																var developerAppDeleteKeysOptions = {
																	'url': developerAppKeysEdgeUrl + ckey.consumerKey,
																	'method': 'DELETE',
																	'headers': {
																		'Content-Type': 'application/json',
																		'Authorization': token
																	},
																	resolveWithFullResponse: true
																};

																await request(developerAppDeleteKeysOptions)
																	.then(async function (developerAppDeleteKeysResponse) {
																		if (developerAppDeleteKeysResponse.statusCode == 200) {
																			grunt.log.ok("Deleted key for Developer App : " + developerAppName);
																		}

																	}).catch((error) => {
																		grunt.log.error("Error occurred while deleting key for developer app : " + developerAppName + " " + error);
																	})
															});

															b64DecdDeveloperAppPayload.credentials.forEach(async credential => {
																let productList = [];
																let keySecret = new Object();
																keySecret.consumerKey = credential.consumerKey;
																keySecret.consumerSecret = credential.consumerSecret;

																credential.apiProducts.forEach(product => {
																	productList.push(product.apiproduct);
																});
																let productPayload = new Object();
																productPayload.apiProducts = productList;

																var developerAppKeysEdgeOptions = {
																	'url': developerAppKeysEdgeUrl + "create",
																	'body': JSON.stringify(keySecret),
																	'method': 'POST',
																	'headers': {
																		'Content-Type': 'application/json',
																		'Authorization': token
																	},
																	resolveWithFullResponse: true
																};
																await request(developerAppKeysEdgeOptions)
																	.then(async function (developerAppKeysEdgeResponse) {
																		if (developerAppKeysEdgeResponse.statusCode == 201) {

																			var ckeyProductsEdgeOptions = {
																				'url': developerAppKeysEdgeUrl + keySecret.consumerKey,
																				'body': JSON.stringify(productPayload),
																				'method': 'POST',
																				'headers': {
																					'Content-Type': 'application/json',
																					'Authorization': token
																				},
																				resolveWithFullResponse: true
																			};

																			await request(ckeyProductsEdgeOptions)
																				.then(async function (ckeyProductsEdgeResponse) {
																					if (ckeyProductsEdgeResponse.statusCode == 200) {
																						grunt.log.ok("Products " + JSON.stringify(productPayload) + " has been attached to the Developer App: " + developerAppName);
																						Promise.resolve(ckeyProductsEdgeResponse.body);
																					}
																				}).catch((error) => {
																					grunt.log.error("Error occurred while adding products for developer app key " + error);
																				})


																		}
																	}).catch((error) => {
																		grunt.log.error("Error occurred while updating key and secret for Developer App " + error);

																	})
															});
															recoveredDeveloperAppsCount++;
															grunt.log.ok("Developer App: " + developerAppName + " has been recovered for the Developer: " + developerEmail);
														}
													}).catch((error) => {
														if (error.statusCode == 401) {
															grunt.log.error("Error occurred while adding Developer App to Edge due to invalid credentials. " + error);
														} else if (error.statusCode == 400) {
															grunt.log.error("Error occurred while adding Developer App to Edge. " + error);
														} else if (error.statusCode == 409) {
															grunt.log.error("Error occurred while adding Developer App as the Developer App already exists. " + error);
														} else if (error.statusCode == 404) {
															grunt.log.error("Error occurred while adding Developer App as the Developer Name doesn't exist in the org. " + error);
														} else {
															grunt.log.error("Unknown Error occurred while adding Developer App. " + error);
														}
													})
											} else {
												//Non 200 HTTP status code received.
												grunt.log.error("Non 200 HTTP status code  received while retrieving Developer App Details. " + error);
											}
										})
										.catch((error) => {
											grunt.log.error("Error occurred while retrieveing Developer App Details from the Database. " + error);
										})
									//}
								}
								grunt.log.ok(recoveredDeveloperAppsCount + " out of " + developerAppIds.length + " Developer Apps have been recovered.");
								grunt.log.ok("Completed Task : recoverDeveloperApps");
							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Non 200 HTTP status code received while retrieving Developer App Ids from the Database. " + error);
						}
					});
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})
	});

	grunt.registerMultiTask('recoverDeveloperApp', 'Restore single Developer App to org ', async function () {
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var fromOrg = grunt.option('apigee_fromorg') || org;
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var resourceName = grunt.option('res_name');

		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverDeveloperApp");
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				var developerAppIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/developer-app/version/" + version + "/name/" + encodeURIComponent(resourceName);
				var developerAppIdOptions = {
					'url': developerAppIdUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				};
				grunt.log.ok("Retrieving ID from the Database for the Developer App using URL: " + developerAppIdUrl);
				await request(developerAppIdOptions)
					.then(async function (developerAppIdResponse) {
						if (developerAppIdResponse.statusCode == 200) {
							var developerAppId = developerAppIdResponse.body;
							if (developerAppId.length == 0) {
								grunt.log.error("No Developer App Id found in the backup Database.");
							} else {
								developerAppIdOptions.url = dbUrl + "/edge/conf/id/" + developerAppId;
								grunt.log.ok("Retrieving Developer App Details from the Database using URL: " + developerAppIdUrl);
								await request(developerAppIdOptions)
									.then(async function (developerAppDetailsResponse) {
										if (developerAppDetailsResponse.statusCode == 200) {
											var developerAppDetailsPayload = JSON.parse(developerAppDetailsResponse.body);
											var b64EncdDeveloperAppPayload = developerAppDetailsPayload["base64-encoded-payload"];
											var buff = Buffer.from(b64EncdDeveloperAppPayload, 'base64');
											let b64DecdDeveloperAppPayload = JSON.parse(buff.toString('utf-8'));
											var developerAppNameNEmail = b64DecdDeveloperAppPayload['name'].split(DEVELOPER_APP_NAME_DELIMITER);
											if (developerAppNameNEmail.length != 2) {
												grunt.log.error("Resource Name doesn't contain both Developer App Name and Developer Email");
												exit;
											}
											var developerEmail = developerAppNameNEmail[0];
											var developerAppName = developerAppNameNEmail[1];

											/* Replacing the Developer App Name with just Developer App Name before posting to Edge,
												because in backupDeveloperApp job the name has been set to DeveloperEmail:DeveloperAppName combination 
												to avoid same App name for multiple developers scenario
											*/
											b64DecdDeveloperAppPayload["name"] = developerAppName;

											// Create developer app object, remove read only properties
											let developerAppObject = new Object();
											developerAppObject.attributes = b64DecdDeveloperAppPayload.attributes;
											developerAppObject.name = b64DecdDeveloperAppPayload.name;
											developerAppObject.callbackUrl = b64DecdDeveloperAppPayload.callbackUrl;

											// Creating Developer App in Edge
											var developerAppEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers/" + developerEmail + "/apps";
											var developerAppEdgeOptions = {
												'url': developerAppEdgeUrl,
												'body': JSON.stringify(developerAppObject),
												'method': 'POST',
												'headers': {
													'Content-Type': 'application/json',
													'Authorization': token
												},
												resolveWithFullResponse: true
											};
											grunt.log.ok("Creating Developer App in Edge using URL: " + developerAppEdgeUrl);
											await request(developerAppEdgeOptions)
												.then(async function (developerAppEdgeResponse) {
													if (developerAppEdgeResponse.statusCode == 201) {

														var developerAppKeysEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers/" + developerEmail + "/apps/" + developerAppName + "/keys/";
														var developerAppEdgeResponsePayload = JSON.parse(developerAppEdgeResponse.body);
														developerAppEdgeResponsePayload.credentials.forEach(async credential => {
															let ckey = new Object();
															ckey.consumerKey = credential.consumerKey;
															//Build options to delete keys
															var developerAppDeleteKeysOptions = {
																'url': developerAppKeysEdgeUrl + ckey.consumerKey,
																'method': 'DELETE',
																'headers': {
																	'Content-Type': 'application/json',
																	'Authorization': token
																},
																resolveWithFullResponse: true
															};

															await request(developerAppDeleteKeysOptions)
																.then(async function (developerAppDeleteKeysResponse) {
																	if (developerAppDeleteKeysResponse.statusCode == 200) {
																		grunt.log.ok("Deleted key for Developer App : " + developerAppName);
																	}

																}).catch((error) => {
																	grunt.log.error("Error occurred while deleting key for developer app : " + developerAppName + " " + error);
																})
														});

														// Build Options to create the key and secret
														b64DecdDeveloperAppPayload.credentials.forEach(async credential => {
															let productList = [];
															let keySecret = new Object();
															keySecret.consumerKey = credential.consumerKey;
															keySecret.consumerSecret = credential.consumerSecret;

															credential.apiProducts.forEach(product => {
																productList.push(product.apiproduct);
															});
															let productPayload = new Object();
															productPayload.apiProducts = productList;
															var developerAppKeysEdgeOptions = {
																'url': developerAppKeysEdgeUrl + "create",
																'body': JSON.stringify(keySecret),
																'method': 'POST',
																'headers': {
																	'Content-Type': 'application/json',
																	'Authorization': token
																},
																resolveWithFullResponse: true
															};
															await request(developerAppKeysEdgeOptions)
																.then(async function (developerAppKeysEdgeResponse) {
																	if (developerAppKeysEdgeResponse.statusCode == 201) {
																		var ckeyProductsEdgeOptions = {
																			'url': developerAppKeysEdgeUrl + keySecret.consumerKey,
																			'body': JSON.stringify(productPayload),
																			'method': 'POST',
																			'headers': {
																				'Content-Type': 'application/json',
																				'Authorization': token
																			},
																			resolveWithFullResponse: true
																		};

																		await request(ckeyProductsEdgeOptions)
																			.then(async function (ckeyProductsEdgeResponse) {
																				if (ckeyProductsEdgeResponse.statusCode == 200) {
																					// grunt.log.ok("Products have been attached to the Developer App: " + developerAppName );
																					Promise.resolve(ckeyProductsEdgeResponse.body);
																				}
																			}).catch((error) => {
																				grunt.log.error("Error occurred while adding products for developer app key " + error);
																			})

																	}
																}).catch((error) => {
																	grunt.log.error("Error occurred while updating key and secret for Developer App " + error);

																})
														});
														grunt.log.ok("Developer App: " + developerAppName + " has been recovered for the Developer: " + developerEmail);
														grunt.log.ok("Completed Task : recoverDeveloperApp");
													}
												}).catch((error) => {
													//Error occurred while Creating Developer in Edge
													if (error.statusCode == 401) {
														grunt.log.error("Error occurred while creating Developer App in Edge due to invalid credentials. " + error);
													} else if (error.statusCode == 400) {
														grunt.log.error("Error occurred while creating Developer App to Edge. " + error);
													} else if (error.statusCode == 409) {
														grunt.log.error("Error occurred while adding Developer App as the Developer App already exists for the Developer. " + error);
													} else if (error.statusCode == 404) {
														grunt.log.error("Error occurred while adding Developer App as the Developer Name doesn't exist in the org. " + error);
													} else {
														grunt.log.error("Unknown Error occurred while creating Developer App. " + error);
													}
												})
										} else {
											//Non 200 HTTP status code received.
											grunt.log.error("Non 200 HTTP status code  received while retrieving Developer App Details from the Database. " + error);
										}

									})
									.catch((error) => {
										grunt.log.error("Error occurred while retrieveing Developer App Details for the ID: " + id + ". " + error);
									})
							}
						} else {
							//Non 200 HTTP status code received.
							grunt.log.error("Error occurred while retrieveing Developer Details for the ID: " + id + ". " + error);
						}
					})
					.catch((error) => {
						grunt.log.error("Error occurred while retrieveing ID from the Database for the Developer App- " + resourceName + ". " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			})
	});
};