/*jslint node: true */
const request = require("request-promise");
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupProducts', 'Backup all products from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var bckdUpProductsCount = 0;
		var done = this.async();
		grunt.log.ok("Started Task : backupProducts");

		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			try {
				//Build Options to retrieve products.
				var productsUrl = edgeUrl + "/v1/organizations/" + org + "/apiproducts";
				var productsOptions = {
					'url': productsUrl,
					'headers': {
						'Authorization': token,
					},
					resolveWithFullResponse: true
				};
				//Get All API Products
				grunt.log.ok("Getting Product using : " + productsOptions.url);
				let productsResponse = await request(productsOptions);
				if (productsResponse.statusCode == 200) {
					//Process productsResponse
					var products = JSON.parse(productsResponse.body);

					// Check number of products
					if (products.length == 0) {
						// No products to backup
						grunt.log.ok("No Products Found to Backup");
					} else {
						//Found Products, process each product.
						for (var productIndex = 0; productIndex < products.length; productIndex++) {
							//Build product details URL
							var productDetailsUrl = productsUrl + "/" + products[productIndex];
							grunt.log.ok("Getting Product Details : " + productDetailsUrl);

							//Get Product Details
							try {
								productsOptions.url = productDetailsUrl;
								let apiProductsDetailsResponse = await request(productsOptions);
								if (apiProductsDetailsResponse.statusCode = 200) {

									var body = apiProductsDetailsResponse.body;
									// Build request to post to the db
									var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/product/version/" + version;
									var postDbOptions = {
										'url': postDbUrl,
										'body': body,
										'method': 'POST',
										'headers': {
											'Content-Type': 'application/json',
											'Authorization': backupApiToken
										},
										resolveWithFullResponse: true
									};
									//Post the data to the Database
									try {
										grunt.log.ok("Backing up Products Details using : " + postDbUrl);
										let backupApiResponse = await request(postDbOptions);
										if (backupApiResponse.statusCode == 200) {
											grunt.log.ok('Post the data to the Database Completed.');
											bckdUpProductsCount++;
										} else {
											//Recieved NON 200 status code while Backing up Product Details into the database
											grunt.log.error("Recieved NON 200 status code while Backing up Product Details into the database, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
										}
									} catch (error) {
										//Error occured while Backingup Products Details into the database
										grunt.log.error("Error occured while Backing up Products Details into the databse. :" + error);
									}
								} else {
									//Recieved NON 200 status code while retrieving Products Details
									grunt.log.error("Recieved NON 200 status code while retrieving Products Details, statusCode : " + apiProductsDetailsResponse.statusCode + " Error: " + apiProductsDetailsResponse.error);
								}
							} catch (error) {
								//Error occurred while Product Details
								grunt.log.error("Error occured while retrieving Product Details. " + error);
							}
						}
					}
					grunt.log.ok("Backed up " + bckdUpProductsCount + " products out of " + products.length);
					done();
				} else {
					//Recieved NON 200 status code while retrieving all Products
					grunt.log.error("Recieved NON 200 status code while retrieving all Products. statusCode : " + productsResponse.statusCode + " Error: " + productsResponse.error);
				}
				//Backup Products Completed
				grunt.log.ok("Completed Task : backupProducts");
			} catch (error) {
				//Error while retrieving all Products
				grunt.log.error("Error occured while retrieving all Products. " + error);
			}
		} catch (error) {
			//Error occured while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
}