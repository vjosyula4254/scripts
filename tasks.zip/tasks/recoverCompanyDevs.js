const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerMultiTask('recoverCompanyDevs', 'Restore all company developers to org ', async function () {
		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;

		var done_count = 0;
		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverCompanyDevs");
		var recoverCompanyDevelopersCount = 0;
		await OauthService.getToken()
			.then(async function (token) {
				return (token);
			})
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				//grunt.log.ok("Token : " + token);
				//Build Options to get the company developer Id from the DB.
				var getCompanyDevelopersUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company-dev/version/" + version;

				var getCompanyDevelopersOptions = {
					'url': getCompanyDevelopersUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true

				};
				//Get All Company Developer from the database.
				grunt.log.ok("Getting Company Developer Id using : " + getCompanyDevelopersOptions.url);
				await request(getCompanyDevelopersOptions)
					.then(async function (companyDevelopersResponse) {
						if (companyDevelopersResponse.statusCode == 200) {
							//	grunt.log.write("Company developer_id: " + body);
							var companyDevelopers = JSON.parse(companyDevelopersResponse.body);
							if (companyDevelopers.length == 0) {
								grunt.log.error("Company Developer NOT found in the backup.");
								//done();
							} else {
								for (var companyDevelopersIndex = 0; companyDevelopersIndex < companyDevelopers.length; companyDevelopersIndex++) {
									//Build Get Company Developers URL
									var getCompanyDevelopersUrl = dbUrl + "/edge/conf/id/" + companyDevelopers[companyDevelopersIndex];
									if (getCompanyDevelopersUrl > 2048) {
										grunt.log.error("SKIPPING Company Developer, URL too long, URL : " + getCompanyDevelopersUrl);
										done_count++;
									} else {
										//Get Company Developer Details
										getCompanyDevelopersOptions.url = getCompanyDevelopersUrl;
										grunt.log.ok("Getting Company Developer detail using url : " + getCompanyDevelopersOptions.url);

										await request(getCompanyDevelopersOptions)
											.then(async function (companyDevelopersDetailsResponse) {

												if (companyDevelopersDetailsResponse.statusCode == 200) {
													//grunt.log.ok("Company Developer :" + companyDevelopersDetailsResponse.body);
													var companyDeveloperDetails = JSON.parse(companyDevelopersDetailsResponse.body);
													var b64EncddCompanyDeveloperDetails = companyDeveloperDetails["base64-encoded-payload"];
													var buff = Buffer.from(b64EncddCompanyDeveloperDetails, 'base64');
													let b64DecddCompanyDeveloperDetails = buff.toString('utf-8');
													var companyString = companyDeveloperDetails["res-name"]
													var companyArray = companyString.split(":");
													var company = companyArray[0];

													// Build Options to create Company Developer in the Edge
													var companyDevelopersUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + company + "/developers";
													var companyDevelopersOptions = {
														'url': companyDevelopersUrl,
														'body': b64DecddCompanyDeveloperDetails,
														'method': 'POST',
														'headers': {
															'Content-Type': 'application/json',
															'Authorization': token
														},
														resolveWithFullResponse: true

													};
													//Create Company Developers into Edge
													grunt.log.ok(" Creating Company Developer into Edge using  : " + companyDevelopersOptions.url);
													//grunt.log.ok(" Creating Company Developer into Edge using Body : " + companyDevelopersOptions.body);
													await request(companyDevelopersOptions)
														.then((companyDevelopersResponse) => {
															if (companyDevelopersResponse.statusCode == 201 || companyDevelopersResponse.statusCode == 200) {
																recoverCompanyDevelopersCount++;
																grunt.log.ok("Company Developers Recovered");
																resolve(companyDevelopersResponse.body);
															}
														})
														.catch((error) => {
															//Error occurred while Creating Company Developer into Edge
															if (error.statusCode == 401) {
																grunt.log.error("Error occurred while adding Company Developer to Edge due to invalid credentials. " + error);
															} else if (error.statusCode == 400) {
																grunt.log.error("Error occurred while adding Company Developer to Edge due to the Error : " + error);
															} else if (error.statusCode == 409) {
																grunt.log.error("Error occurred while adding Company Developer as Company Developer exists. " + error);
															}
														})


												}

											})
											.catch((error) => {
												//Error occured while getting company developers Details from the Database
												grunt.log.error("Error occured while getting company developer Details from the Database. " + error);
											})

									}
								}
								grunt.log.ok(recoverCompanyDevelopersCount + " out of " + companyDevelopers.length + " company developer have been recovered.");
								grunt.log.ok("Completed Task : recoverCompanyDevelopers");
							}
						}
					})
					.catch((error) => {
						//Error occurred while getting Company Developer List from the Database
						grunt.log.error("Error occurred while getting company developer List from the Database. " + error);
					})
			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});

	})



	grunt.registerMultiTask('recoverCompanyDev', 'Restore single company developer to org ', async function () {

		// Process grunt command line options
		var org = grunt.option('apigee_org') || "fei-sidgs";
		var resourceName = grunt.option('res_name') || "fei-orchestration:sap0078@ferguson.com"
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
		var fromOrg = grunt.option('apigee_fromorg') || org;


		var dbUrl = apigee.db.url;
		var edgeUrl = apigee.to.url;

		var done = this.async();
		grunt.log.ok("Started Task : recoverCompanyDev");
		await OauthService.getToken()
			.then(async function (token) {
				//Token received
				//grunt.log.ok("Token : " + token);
				return (token);
			})
			//Get company developer Id from the DB.
			.then(async function (token) {
				//Get Token for Backup API Service
				var backupApiToken = "";
				if (apigee.db.account) {
					backupApiToken = await backupApiTokenService.getBackupServiceToken();
				}

				//grunt.log.ok("Token : " + token);
				//Build Options to get the company developer Id from the DB.
				var getCompanyDeveloperUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/company-dev/version/" + version + "/name/" + resourceName;
				var getCompanyDeveloperOptions = {
					'url': getCompanyDeveloperUrl,
					'headers': {
						'Content-Type': 'application/json',
						'Authorization': backupApiToken
					},
					resolveWithFullResponse: true
				}
				//Get company developer backup Id from the Database
				grunt.log.ok("Getting Company Developers Id using : " + getCompanyDeveloperOptions.url);
				await request(getCompanyDeveloperOptions)
					.then(async function (companyDeveloperResponse) {
						if (companyDeveloperResponse.statusCode == 200) {
							var companyDeveloperId = companyDeveloperResponse.body;
							if (companyDeveloperId.length == 0) {
								grunt.log.error("Company Developers NOT found in the backup.");
							} else {
								//Company Developers Id found ing the backup.
								grunt.log.ok("Company Developers Found. Id : " + companyDeveloperId);

								//Get Company Developers Details
								getCompanyDeveloperOptions.url = dbUrl + "/edge/conf/id/" + companyDeveloperId;
								grunt.log.ok("Getting Company Developers Details using :" + getCompanyDeveloperOptions.url)
								await request(getCompanyDeveloperOptions)
									.then(async function (companyDeveloperDetailsResponse) {

										if (companyDeveloperDetailsResponse.statusCode == 200) {
											//grunt.log.ok("Company Developers :" + companyDeveloperDetailsResponse.body);
											var companyDeveloperDetails = JSON.parse(companyDeveloperDetailsResponse.body);
											var b64EncddCompanyDeveloperDetails = companyDeveloperDetails["base64-encoded-payload"];
											var buff = Buffer.from(b64EncddCompanyDeveloperDetails, 'base64');
											let b64DecddCompanyDeveloperDetails = buff.toString('utf-8');
											var companyString = companyDeveloperDetails["res-name"]
											var companyArray = companyString.split(":");
											var company = companyArray[0];

											// Build Options to create Company Developers in the Edge
											var companyDevelopersUrl = edgeUrl + "v1/organizations/" + org + "/companies/" + company + "/developers";
											var companyDevelopersOptions = {
												'url': companyDevelopersUrl,
												'body': b64DecddCompanyDeveloperDetails,
												'method': 'POST',
												'headers': {
													'Content-Type': 'application/json',
													'Authorization': token
												},
												resolveWithFullResponse: true

											};
											var dbResourceName = JSON.parse(b64DecddCompanyDeveloperDetails).name;
											if (JSON.stringify(dbResourceName) === JSON.stringify(resourceName)) {
												//Create Company Developers
												grunt.log.ok(" Creating Company Developers into Edge using Url : " + companyDevelopersOptions.url);
												//grunt.log.ok(" Creating Company Developers into Edge using Body : " + companyDevelopersOptions.body);
												await request(companyDevelopersOptions)
													.then((companyDeveloperDetailsResponse) => {
														if (companyDeveloperDetailsResponse.statusCode == 201 || companyDeveloperDetailsResponse.statusCode == 200) {
															grunt.log.ok("Company Developers : " + resourceName + " has been recovered.");
															grunt.log.ok("Completed Task : recoverCompanyDev");
															resolve(companyDeveloperDetailsResponse.body);
														}
													}).catch((error) => {
														if (error.statusCode == 401) {
															grunt.log.error("Error occurred while adding Company Developer to Edge due to invalid credentials. " + error);
														} else if (error.statusCode == 400) {
															grunt.log.error("Error occurred while adding Company Developer to Edge due to the Error : " + error);
														} else if (error.statusCode == 409) {
															grunt.log.error("Error occurred while adding Company Developers as Company Developer exists. " + error);
														}
													})

											}
										}

									})
									.catch((error) => {
										//Error occured while getting company developer Details from the Database
										grunt.log.error("Error occured while getting company developer Details from the Database. " + error);
									})

							}
						}
					})
			})
			.catch((error) => {
				//Error occured while getting company developer backup Id from the Database
				grunt.log.error("Error occured while getting company developer backup Id from the Database. " + error);

			})
			.catch((error) => {
				//Error occured while getting Token
				grunt.log.error("Error occured while getting Token. " + error);
				Promise.resolve(error);
			});
	});
}; //module closing