var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const request = require('request');
const NodeCache = require('node-cache');

module.exports.getToken = async function getToken() {

  return new Promise((resolve, reject) => {

    this.tokenKey = 'tokenKey';
    this.cache = new NodeCache({
      stdTTL: 300,
      checkperiod: 60
    });

    let cachedToken = this.cache.get(this.tokenKey);
    if (cachedToken) {
      //console.log('cache hit');
      resolve(cachedToken)
    } else {
      var username = apigee.to.userid;
      var password = apigee.to.passwd;
      var tokenurl = apigee.to.tokenurl;

      let cache = this.cache;
      let tokenKey = this.tokenKey;
      var options = {
        'method': 'POST',
        'url': tokenurl,
        'headers': {
          'Accept': 'application/json',
          'Authorization': 'Basic ZWRnZWNsaTplZGdlY2xpc2VjcmV0',
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        form: {
          'grant_type': 'password',
          'response_type': 'token',
          'username': username,
          'password': password
        }
      };
      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          let token = "Bearer" + " " + JSON.parse(body).access_token;
          cache.set(tokenKey, token);
          resolve(token);
        } else {
          reject(new Error('Unable to generate token'));
        }
      });
    }

  });
}