const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
    'use strict';
    grunt.registerMultiTask('recoverEnvKvms', 'Restore all env-Kvms to org ', async function () {
        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverKvmCnt = 0;
        var invalidKvmCnt = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;

        var done = this.async();
        grunt.log.ok("Started Task : recoverEnvKvms");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //Build Options to get KVM Ids from the DB.
                var kvmIdsUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/kvm/version/" + version;
                var kvmIdsOptions = {
                    'url': kvmIdsUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                //Get KVM Ids from the database.
                grunt.log.ok("Getting KVM Ids using : " + kvmIdsOptions.url);
                await request(kvmIdsOptions)
                    .then(async function (kvmIdsResponse) {
                        if (kvmIdsResponse.statusCode == 200) {
                            var kvmIds = JSON.parse(kvmIdsResponse.body);
                            if (kvmIds.length == 0) {
                                grunt.log.error("No KVM Ids found in the backup Database.");
                                //done();
                            } else {
                                for (var kvmIdIndex = 0; kvmIdIndex < kvmIds.length; kvmIdIndex++) {
                                    //Found KVMs for the backup
                                    var kvmDetailsUrl = apigee.db.url + "/edge/conf/id/" + kvmIds[kvmIdIndex];
                                    if (kvmIds.length > 2048) {
                                        invalidKvmCnt++;
                                        grunt.log.ok("SKIPPING kvm, URL too long: ");
                                    } else {
                                        //build KVM Details Url
                                        kvmIdsOptions.url = kvmDetailsUrl;
                                        //Get KVM Details
                                        grunt.log.ok("Getting KVM Details using : " + kvmIdsOptions.url);
                                        await request(kvmIdsOptions)
                                            .then(async function (kvmDetailsResponse) {
                                                if (kvmDetailsResponse.statusCode == 200) {
                                                    //Get KVM Name and KVM Environment
                                                    var kvmDetails = JSON.parse(kvmDetailsResponse.body);
                                                    var kvmEnv = kvmDetails["env-name"];
                                                    var b64EncdKvmPayload = kvmDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdKvmPayload, 'base64');
                                                    let b64DecdKvmPayload = buff.toString('utf-8');

                                                    //grunt.log.ok("kvmName : " + kvmName + ",  kvmEnv : " + kvmEnv);
                                                    // Build Options to create KVM in the Edge
                                                    var kvmEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + kvmEnv + "/keyvaluemaps";
                                                    var kvmEdgeOptions = {
                                                        'url': kvmEdgeUrl,
                                                        'body': b64DecdKvmPayload,
                                                        'method': 'POST',
                                                        'headers': {
                                                            'Content-Type': 'application/json',
                                                            'Authorization': token
                                                        },
                                                        resolveWithFullResponse: true

                                                    };
                                                    //Create KVM into Edge
                                                    grunt.log.ok(" Creating KVM into Edge using Url : " + kvmEdgeOptions.url);
                                                    await request(kvmEdgeOptions)
                                                        .then(async function (kvmEdgeResponse) {
                                                            if (kvmEdgeResponse.statusCode == 201) {
                                                                recoverKvmCnt++;
                                                                //grunt.log.ok("KVM: " + kvmName + " in environment: " + env + " have been Recovered.");
                                                                //Promise.resolve(kvmEdgeResponse.body);
                                                            }
                                                        })
                                                        .catch((error) => {
                                                            //Error occurred while Creating KVM into Edge
                                                            if (error.statusCode == 401) {
                                                                grunt.log.error("Error occurred while adding KVM to Edge due to invalid credentials. " + error);
                                                            } else if (error.statusCode == 400) {
                                                                grunt.log.error("Error occurred while adding KVM to Edge. " + error);
                                                            } else if (error.statusCode == 409) {
                                                                grunt.log.error("Error occurred while adding KVM as API KVM already exists. " + error);
                                                            } else {
                                                                grunt.log.error("Unknown Error occurred while adding KVM. " + error);
                                                            }
                                                        });

                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving KVM Details. " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing KVM Details. " + error);
                                            })
                                    }
                                }
                            }

                            grunt.log.ok(`${recoverKvmCnt} out of ${kvmIds.length - invalidKvmCnt} KVMs have been recovered.`);
                            grunt.log.ok("Completed Task : recoverKVMs");

                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving KVM Ids. " + error);
                        }
                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing KVM Ids. " + error);
                    })
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            });

    });


    grunt.registerMultiTask('recoverEnvKvm', 'Restore single env-Env to org ', async function () {
        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var resourceName = grunt.option('res_name') || "bidtracerKVM"
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var dbUrl = apigee.db.url;
        grunt.log.ok("Started Task : recoverEnvKvm");
        var edgeUrl = apigee.to.url;

        var done = this.async();
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //Build Options to get KVM Ids from the DB.
                var kvmIdsUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/kvm/version/" + version;
                var kvmIdsOptions = {
                    'url': kvmIdsUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                //Get KVM Ids from the database.
                grunt.log.ok("Getting KVM Ids using : " + kvmIdsOptions.url);
                await request(kvmIdsOptions)
                    .then(async function (kvmIdsResponse) {
                        //grunt.log.ok(JSON.stringify(kvmIdsResponse.body));

                        if (kvmIdsResponse.statusCode == 200) {
                            var kvmIds = JSON.parse(kvmIdsResponse.body);
                            if (kvmIds.length == 0) {
                                grunt.log.error("No JVM Ids found in the backup Database.");
                                //done();
                            } else {
                                var kvmFound = false;
                                for (var kvmIdIndex = 0; kvmIdIndex < kvmIds.length && !kvmFound; kvmIdIndex++) {
                                    //Found KVMs for the backup
                                    var kvmDetailsUrl = apigee.db.url + "/edge/conf/id/" + kvmIds[kvmIdIndex];
                                    if (kvmIds.length > 2048) {
                                        grunt.log.ok("SKIPPING kvm, URL too long: ");
                                    } else {
                                        //build KVM Details Url
                                        kvmIdsOptions.url = kvmDetailsUrl;
                                        //Get KVM Details
                                        //grunt.log.ok("Getting KVM Details using : " + kvmIdsOptions.url);
                                        await request(kvmIdsOptions)
                                            .then(async function (kvmDetailsResponse) {
                                                if (kvmDetailsResponse.statusCode == 200) {
                                                    //Get KVM Name and KVM Environment
                                                    var kvmDetails = JSON.parse(kvmDetailsResponse.body);
                                                    var b64EncdKvmPayload = kvmDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdKvmPayload, 'base64');
                                                    let b64DecdKvmPayload = JSON.parse(buff.toString('utf-8'));

                                                    var kvmName = b64DecdKvmPayload["name"];
                                                    var kvmEnv = kvmDetails["env-name"];
                                                    //grunt.log.ok("kvmName : " + kvmName + ",  kvmEnv : " + kvmEnv);
                                                    if (kvmName == resourceName && env == kvmEnv) {
                                                        // Build Options to create KVM in the Edge
                                                        var kvmEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + env + "/keyvaluemaps";
                                                        var kvmEdgeOptions = {
                                                            'url': kvmEdgeUrl,
                                                            'body': JSON.stringify(b64DecdKvmPayload),
                                                            'method': 'POST',
                                                            'headers': {
                                                                'Content-Type': 'application/json',
                                                                'Authorization': token
                                                            },
                                                            resolveWithFullResponse: true

                                                        };
                                                        //Create KVM into Edge
                                                        grunt.log.ok(" Creating KVM into Edge using Url : " + kvmEdgeOptions.url);
                                                        await request(kvmEdgeOptions)
                                                            .then(async function (kvmEdgeResponse) {
                                                                if (kvmEdgeResponse.statusCode == 201) {
                                                                    grunt.log.ok("KVM: " + kvmName + " in environment: " + env + " has been recovered.");
                                                                    kvmFound = true;
                                                                    Promise.resolve(kvmEdgeResponse.body);
                                                                }
                                                            })
                                                            .catch((error) => {
                                                                //Error occurred while Creating KVM into Edge
                                                                if (error.statusCode == 401) {
                                                                    grunt.log.error("Error occurred while adding KVM to Edge due to invalid credentials. " + error);
                                                                } else if (error.statusCode == 400) {
                                                                    grunt.log.error("Error occurred while adding KVM to Edge. " + error);
                                                                } else if (error.statusCode == 409) {
                                                                    grunt.log.error("Error occurred while adding KVM as API KVM already exists. " + error);
                                                                } else {
                                                                    grunt.log.error("Unknown Error occurred while adding KVM. " + error);
                                                                }
                                                            })
                                                        //})
                                                    }
                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving KVM Details. " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing KVM Details. " + error);
                                            })
                                    }
                                }
                                //KVM not found.
                                if (!kvmFound) {
                                    grunt.log.error(resourceName + " KVM not found. ");
                                }
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving KVM Ids. " + error);
                        }
                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing KVM Ids. " + error);
                    })
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            });

    });
};