/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev_secure';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');


module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupCompanies', 'Backup all companies from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var done = this.async();

		grunt.log.ok("Started Task : backupCompanies");
		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			var companies;
			var bckdUpCompaniesCount = 0;

			try {
				var apigeeCompaniesUrl = edgeUrl + "/v1/organizations/" + org + "/companies";

				var companiesOptions = {
					'url': apigeeCompaniesUrl,
					'headers': {
						'Authorization': token,
					},
					resolveWithFullResponse: true
				};
				//Get All Company Names
				let companiesResponse = await request(companiesOptions);
				if (companiesResponse.statusCode == 200) {
					companies = JSON.parse(companiesResponse.body);

					if (companies.length == 0) {
						grunt.log.ok("No Companies Found to Backup");
						done();
					}
					for (var i = 0; i < companies.length; i++) {
						var apigeeCompanyInforUrl = apigeeCompaniesUrl + "/" + companies[i];

						//Get Company Details for Each Company
						var companyDetailsOptions = {
							'url': apigeeCompanyInforUrl,
							'headers': {
								'Authorization': token,
							},
							resolveWithFullResponse: true
						};
						try {
							let companyDetailsResponse = await request(companyDetailsOptions);
							if (companyDetailsResponse.statusCode == 200) {
								var companyDetails = JSON.parse(companyDetailsResponse.body);
								var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/company/version/" + version;
								var postDbOptions = {
									'url': postDbUrl,
									'body': companyDetailsResponse.body,
									'method': 'POST',
									'headers': {
										'Content-Type': 'application/json',
										'Authorization': backupApiToken
									},
									resolveWithFullResponse: true
								};
								//Post the data to the Database
								try {
									grunt.log.ok("Backing up Company Details using : " + postDbUrl);
									let backupApiResponse = await request(postDbOptions);
									if (backupApiResponse.statusCode == 200) {
										grunt.log.ok('Post the data to the Database Completed : ');
										bckdUpCompaniesCount++;
									} else {
										//Recieved NON 200 status code while Backing up Company Details into the database
										grunt.log.error("Error while Backing up Company Details into the database, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
									}
								} catch (error) {
									//Error occurred while  Backingup Company Details into the databse
									grunt.log.error("Error while Backing up Company  Details into the databse. error : " + error);
								}
							} else {
								//Recieved NON 200 status code while Getting Company Details for a Company
								grunt.log.error("Recieved NON 200 status code while getting Getting Company Details for a Company, statusCode : " + companyDetailsResponse.statusCode + " Error: " + companyDetailsResponse.error);
							}
						} catch (error) {
							//Error occurred while Retrieving Company Details
							grunt.log.error("Error while Retrieving Company Details for company- " + companies[i] + ". status code :" + error.statusCode + " error : " + error.error);
						}
					}
					grunt.log.ok('Backed up ' + bckdUpCompaniesCount + ' Companies out of ' + companies.length + ' Companies');
				} else {
					//Recieved NON 200 status code while Getting Companies
					grunt.log.error("Recieved NON 200 status code while getting companies, statusCode : " + companiesResponse.statusCode + " Error: " + companiesResponse.error);
				}
				//Backup Companies Completed
				grunt.log.ok("Completed Task : backupCompanies");
			} catch (error) {
				//Error Getting Companies
				grunt.log.error("Error occurred in backupCompanies Task. " + error);
			}
		} catch (error) {
			//Error while getting Token
			grunt.log.error("Error occurred while getting Token. " + error);
		}
	});
}