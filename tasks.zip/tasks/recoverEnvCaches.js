const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
    'use strict';
    grunt.registerMultiTask('recoverEnvCaches', 'Restore all env-cache to org ', async function () {

        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverCacheCount = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;

        var done = this.async();
        grunt.log.ok("Started Task : recoverEnvCaches");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //Build Options to get Cache Ids from the DB.
                var cacheIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/cache/version/" + version;
                var cacheIdOptions = {
                    'url': cacheIdUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                //Get Cache Ids from the database.
                //grunt.log.ok("Getting Cache Ids using : " + cacheIdOptions.url);
                await request(cacheIdOptions)
                    .then(async function (cacheIdResponse) {
                        if (cacheIdResponse.statusCode == 200) {
                            var cacheIds = JSON.parse(cacheIdResponse.body);
                            if (cacheIds.length == 0) {
                                grunt.log.error("No Cache Ids found in the backup Database.");
                                //done();
                            } else {
                                for (var cacheIdIndex = 0; cacheIdIndex < cacheIds.length; cacheIdIndex++) {
                                    //Found Cache Ids for the backup
                                    var cacheDetailsUrl = apigee.db.url + "/edge/conf/id/" + cacheIds[cacheIdIndex];
                                    //Call Cache details
                                    if (cacheIds.length > 2048) {
                                        grunt.log.ok("SKIPPING Cache, URL too long: ");
                                        recoverCacheCount++;
                                    } else {
                                        //build Chache Details Url
                                        cacheIdOptions.url = cacheDetailsUrl;
                                        //Get Cache Details
                                        //grunt.log.ok("Getting Cache Details using : " + cacheIdOptions.url);
                                        await request(cacheIdOptions)
                                            .then(async function (cacheDetailsResponse) {
                                                if (cacheDetailsResponse.statusCode == 200) {
                                                    //Get Cache Name and Cache Environment
                                                    var cacheDetails = JSON.parse(cacheDetailsResponse.body);
                                                    var b64EncdCachepayload = cacheDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdCachepayload, 'base64');
                                                    let b64DecdCachePayload = JSON.parse(buff.toString('utf-8'));

                                                    var cacheName = b64DecdCachePayload["name"];;
                                                    var cacheEnv = cacheDetails["env-name"];
                                                    //grunt.log.ok("cacheName : " + cacheName + ",  cacheEnv : " + cacheEnv);

                                                    // Build Options to create Cache in the Edge
                                                    var cacheEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + cacheEnv + "/caches";
                                                    //grunt.log.ok("Post Edge URL:" + cacheEdgeUrl);
                                                    var cacheEdgeOptions = {
                                                        'url': cacheEdgeUrl,
                                                        'body': JSON.stringify(b64DecdCachePayload),
                                                        'method': 'POST',
                                                        'headers': {
                                                            'Content-Type': 'application/json',
                                                            'Authorization': token
                                                        },
                                                        resolveWithFullResponse: true
                                                    };
                                                    //Create Cache into Edge
                                                    //grunt.log.ok(" Creating Cache into Edge using Url : " + cacheEdgeOptions.url);
                                                    await request(cacheEdgeOptions)
                                                        .then(async function (cacheEdgeResponse) {
                                                            if (cacheEdgeResponse.statusCode == 201) {
                                                                recoverCacheCount++;
                                                                grunt.log.ok("cache : " + cacheName + " in environment: " + cacheEnv + " have been Recovered.");
                                                            }
                                                        })
                                                        .catch((error) => {
                                                            //Error occurred while Creating Cache into Edge
                                                            if (error.statusCode == 401) {
                                                                grunt.log.error("Error occurred while adding Cache to Edge due to invalid credentials. " + error);
                                                            } else if (error.statusCode == 400) {
                                                                grunt.log.error("Error occurred while adding Cache to Edge. " + error);
                                                            } else if (error.statusCode == 409) {
                                                                grunt.log.error("Error occurred while adding Cache as API Cache already exists. " + error);
                                                            } else {
                                                                grunt.log.error("Unknown Error occurred while adding Cache. " + error);
                                                            }
                                                        })
                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving Cache Details. " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing Cache Details. " + error);
                                            })
                                    }
                                }
                                grunt.log.ok(recoverCacheCount + " out of " + cacheIds.length + " Caches have been recovered.");
                                grunt.log.ok("Completed Task : recoverCaches");
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving Cache Ids. " + error);
                        }
                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing Cache Ids. " + error);
                    })
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            })
    });


    grunt.registerMultiTask('recoverEnvCache', 'Restore single env-cache to org ', async function () {
        // Process grunt command line options
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var env = grunt.option('apigee_env') || "mock";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT";
        var resourceName = grunt.option('res_name');
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverCacheCount = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;

        var done = this.async();
        grunt.log.ok("Started Task : recoverEnvCache");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                //Build Options to get Cache Ids from the DB.
                var cacheIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/cache/version/" + version;
                var cacheIdOptions = {
                    'url': cacheIdUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                //Get Cache Ids from the database.
                grunt.log.ok("Getting Cache Ids using : " + cacheIdOptions.url);
                await request(cacheIdOptions)
                    .then(async function (cacheIdResponse) {
                        if (cacheIdResponse.statusCode == 200) {
                            var cacheIds = JSON.parse(cacheIdResponse.body);
                            if (cacheIds.length == 0) {
                                grunt.log.error("No Cache Ids found in the backup Database.");
                                //done();
                            } else {
                                //Found Cache Ids for the backup
                                var cacheFound = false
                                for (var cacheIdIndex = 0; cacheIdIndex < cacheIds.length && !cacheFound; cacheIdIndex++) {
                                    //Found Cache Ids for the backup
                                    var cacheDetailsUrl = apigee.db.url + "/edge/conf/id/" + cacheIds[cacheIdIndex];
                                    //Call Cache details
                                    if (cacheIds.length > 2048) {
                                        grunt.log.ok("SKIPPING Cache, URL too long: ");
                                        recoverCacheCount++;
                                    } else {
                                        //build Chache Details Url
                                        cacheIdOptions.url = cacheDetailsUrl;
                                        //Get Chache Details
                                        //grunt.log.ok("Getting Cache Details using : " + cacheIdOptions.url);
                                        await request(cacheIdOptions)
                                            .then(async function (cacheDetailsResponse) {
                                                if (cacheDetailsResponse.statusCode == 200) {
                                                    //Get Cache Name and Cache Environment
                                                    var cacheDetails = JSON.parse(cacheDetailsResponse.body);
                                                    var b64EncdCachepayload = cacheDetails["base64-encoded-payload"];
                                                    var buff = Buffer.from(b64EncdCachepayload, 'base64');
                                                    let b64DecdCachePayload = JSON.parse(buff.toString('utf-8'));

                                                    var cacheName = b64DecdCachePayload["name"];;
                                                    var cacheEnv = cacheDetails["env-name"];
                                                    //grunt.log.ok("cacheName : " + cacheName + ",  cacheEnv : " + cacheEnv);

                                                    if (cacheName == resourceName && env == cacheEnv) {
                                                        cacheFound = true;
                                                        // Build Options to create Cache in the Edge
                                                        var cacheEdgeUrl = edgeUrl + "v1/organizations/" + org + "/environments/" + env + "/caches";
                                                        //grunt.log.ok("Post Edge URL:" + cacheEdgeUrl);
                                                        var cacheEdgeOptions = {
                                                            'url': cacheEdgeUrl,
                                                            'body': JSON.stringify(b64DecdCachePayload),
                                                            'method': 'POST',
                                                            'headers': {
                                                                'Content-Type': 'application/json',
                                                                'Authorization': token
                                                            },
                                                            resolveWithFullResponse: true
                                                        };
                                                        //Create Cache into Edge
                                                        grunt.log.ok(" Creating Cache into Edge using Url : " + cacheEdgeOptions.url);
                                                        await request(cacheEdgeOptions)
                                                            .then(async function (cacheEdgeResponse) {
                                                                if (cacheEdgeResponse.statusCode == 201) {
                                                                    grunt.log.ok("cache : " + cacheName + " in environment: " + env + " has been recovered.");
                                                                    grunt.log.ok("Completed Task : recoverEnvCache");
                                                                    Promise.resolve(cacheEdgeResponse.body);
                                                                }
                                                            })
                                                            .catch((error) => {
                                                                //Error occurred while Creating Cache into Edge
                                                                if (error.statusCode == 401) {
                                                                    grunt.log.error("Error occurred while adding Cache to Edge due to invalid credentials. " + error);
                                                                } else if (error.statusCode == 400) {
                                                                    grunt.log.error("Error occurred while adding Cache to Edge. " + error);
                                                                } else if (error.statusCode == 409) {
                                                                    grunt.log.error("Error occurred while adding Cache as API Cache already exists. " + error);
                                                                } else {
                                                                    grunt.log.error("Unknown Error occurred while adding Cache. " + error);
                                                                }
                                                            })
                                                    }
                                                } else {
                                                    //Non 200 HTTP status code received.
                                                    grunt.log.error("Non 200 HTTP status code  received retrieving Cache Details. " + error);
                                                }
                                            })
                                            .catch((error) => {
                                                grunt.log.error("Error occurred while retrieveing Cache Details. " + error);
                                            })
                                    }
                                }
                                if (!cacheFound) {
                                    //Cache not found.
                                    grunt.log.error(resourceName + " Cache not found. ");
                                }
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving Cache Ids. " + error);
                        }
                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing Cache Ids. " + error);
                    })
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            })

    });
}