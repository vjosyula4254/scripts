/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupCompanyDevs', 'Backup all company devs from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var companyCount = 0;
		var companyDevCount = 0;
		var totalBckdUpDevelopers = 0;
		var done = this.async();

		var backupAllDevelopersInACompany = async function (companyName) {
			var companyDevelopersUrl = edgeUrl + "/v1/organizations/" + org + "/companies" + "/" + companyName + "/developers";
			//Build Options to get All developers in a Company
			var companyDevelopersOption = {
				'url': companyDevelopersUrl,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};

			//Get all Developers for a Company
			grunt.log.ok("Getting All Developers for a Comapany using : " + companyDevelopersOption.url);
			try {
				let companyDevelopersResponse = await request(companyDevelopersOption);

				if (companyDevelopersResponse.statusCode == 200) {
					var companyDevelopers = JSON.parse(companyDevelopersResponse.body);
					if (companyDevelopers) {
						grunt.log.ok("Retrieved developers for Company :" + companyName);
						//Add company name in company developer payload 
						var companyDeveloper;
						for (companyDeveloper in companyDevelopers.developer) {
							var companyDevBody = companyDevelopers.developer[companyDeveloper];
							var companyDev = '{"developer":[' + JSON.stringify(companyDevBody) + ']}';
							var companyDevObject = JSON.parse(companyDev);
							companyDevObject.name = companyName + ":" + companyDevBody.email;

							//Build Options for adding companyDevelopers into the database
							var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/company-dev/version/" + version
							var postDbOptions = {
								'url': postDbUrl,
								// 'body': JSON.stringify(companyDevelopers),
								'body': JSON.stringify(companyDevObject),
								'method': 'POST',
								'headers': {
									'Content-Type': 'application/json',
									'Authorization': backupApiToken
								},
								resolveWithFullResponse: true
							};
							//Post the data to the Database
							try {
								grunt.log.ok("Backing up Company Developers using : " + postDbOptions.url);
								let backupApiResponse = await request(postDbOptions);
								if (backupApiResponse.statusCode == 200) {
									grunt.log.ok('Posting of the Data to the Database Completed : ' + backupApiResponse.body);
									totalBckdUpDevelopers++;
								} else {
									//Recieved NON 200 status code while Backing up Company Developers into the database
									grunt.log.error("Recieved NON 200 status while posting Company Developers to the Database, statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
								}
							} catch (error) {
								//Error occurred while  Backing up Company Developers into the databse
								grunt.log.error("Error occured while posting Company Developers to the Database. Error :" + error);
							}
							companyDevCount++;
						}
						grunt.log.ok('Backed up ' + totalBckdUpDevelopers + ' Company Developers out of ' + companyDevCount + " Company Developers for " + companyCount + " Companies.");
					} else {
						grunt.log.ok('No Company Developers to backup.  companyDevelopers : ' + JSON.stringify(companyDevelopers));
					}
				} else {
					//Recieved NON 200 status code retrieving Company Developers
					grunt.log.error("Recieved NON 200 status code while retrieving Company Developers. StatusCode: " + companyDevelopersResponse.statusCode + ", Error : " + companyDevelopersResponse.body);
				}
			} catch (error) {
				//Error occured while retrieving Company Developers
				grunt.log.error("Error occured while retrieving Company Developers. " + error);
			}
		}

		var backupAllCompaniesDevlopers = async function (startCompanyName) {
			var companiesUrlWithStartkey = edgeUrl + "/v1/organizations/" + org + "/companies";
			if (startCompanyName) {
				companiesUrlWithStartkey += "?startKey=" + encodeURIComponent(startCompanyName);
			}
			//Build Options to get All Companies
			var companiesOptions = {
				'url': companiesUrlWithStartkey,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};
			//Get All Companies
			grunt.log.ok("Getting All Companies using : " + companiesUrlWithStartkey);
			try {
				let companiesRespose = await request(companiesOptions);
				if (companiesRespose.statusCode = 200) {
					//Companies retrieved
					var companies = JSON.parse(companiesRespose.body);

					if (companies.length > 0) {
						if (startCompanyName) {
							/*	APIGEE SaaS MGMT APIs returns only 1000 companies in one management call
								this is to check if backupAllCompanyDevlopers called recursively ( for more than 1000 companies),
								if that the case then startCompanyName will have the company which we provided
								as a startKey, so we should not process the first Company from this list. Remove first Company.
							*/
							//Remove first company from the list.
							grunt.log.ok("removing " + companies[0] + "form the list");
							companies.shift();
						}

						// Process remaining Companies
						if (companies.length > 0) {
							companyCount += companies.length
							for (var companyIndex = 0; companyIndex < companies.length; companyIndex++) {
								grunt.log.ok("Backing up All Developers in for the Company : " + companies[companyIndex]);
								await backupAllDevelopersInACompany(companies[companyIndex]);
							}

							/* 	APIGEE cloud returns only 1000 companies in one management call
								If number of Companies are >=1000   then there is possibility that there
								are more companies. Make a recursive call to get all the companies 
								until all companies are retrieved.
							*/
							if (companies.length >= 999) {
								lastCompany = companies[companies.length - 1];
								backupAllCompaniesDevlopers(lastCompany);
							}
						}

					} else {
						grunt.log.ok('No App Companies Found.');
					}
				} else {
					//Received non 200 HTTP call from retrieve companies
					grunt.log.error("Error while retrieving Companies. " + error);
				}
			} catch (error) {
				//Error occured while retrieving Company Developers
				grunt.log.error("Error occured while retrieving All Companies. " + error);
			}
		}
		// Start backupCompanyDevs Task
		grunt.log.ok("Started Task : backupCompanyDevs");

		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			//Backup all CompanyDevelopers
			await backupAllCompaniesDevlopers(null);
		} catch (error) {
			//Error occured while getting Token
			grunt.log.error("Error occured while doing backupCompanyDevs Task. " + error);
		}
	});
};