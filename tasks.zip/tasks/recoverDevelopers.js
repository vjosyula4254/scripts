const request = require("request-promise");
const OauthService = require('./oauthServiceForToOrg');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
const backupApiTokenService = require('./backapiTokenService');

module.exports = function (grunt) {
    'use strict';
    grunt.registerMultiTask('recoverDevelopers', 'Restore all Developers to org ', async function () {
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
        var fromOrg = grunt.option('apigee_fromorg') || org;

        var recoverDeveloperCount = 0;
        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;

        var done = this.async();
        grunt.log.ok("Started Task : recoverDevelopers");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                var developerIdUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/developer/version/" + version;
                var developerEdgeOptions = {
                    'url': developerIdUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                grunt.log.ok("Retrieving Developer Ids from the Database");
                await request(developerEdgeOptions)
                    .then(async function (companyIdResponse) {
                        if (companyIdResponse.statusCode == 200) {
                            var developerIds = JSON.parse(companyIdResponse.body);
                            if (developerIds.length == 0) {
                                grunt.log.error("No Developer Ids found in the backup Database.");
                                //done();
                            } else {
                                //Found Developer Ids for backup
                                for (var developerIdIndex = 0; developerIdIndex < developerIds.length; developerIdIndex++) {
                                    var developerDetailsDbUrl = apigee.db.url + "/edge/conf/id/" + developerIds[developerIdIndex];
                                    //Build Developer Details Url
                                    developerEdgeOptions.url = developerDetailsDbUrl;
                                    //Call Developer details
                                    grunt.log.ok("Retrieving Developer Details from the Database Using the URL: " + developerDetailsDbUrl);
                                    await request(developerEdgeOptions)
                                        .then(async function (developerDetailsResponse) {
                                            if (developerDetailsResponse.statusCode == 200) {
                                                var developerDetails = JSON.parse(developerDetailsResponse.body);
                                                var b64EncdDeveloperPayload = developerDetails["base64-encoded-payload"];
                                                var buff = new Buffer(b64EncdDeveloperPayload, 'base64');
                                                let b64DecdDeveloperPayload = JSON.parse(buff.toString('utf-8'));
                                                //Get Developer Email
                                                var developerEmail = b64DecdDeveloperPayload["email"];
                                                // Build Options to create Developer in Edge
                                                var developerEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers";
                                                var developerPostEdgeOptions = {
                                                    'url': developerEdgeUrl,
                                                    'body': JSON.stringify(b64DecdDeveloperPayload),
                                                    'method': 'POST',
                                                    'headers': {
                                                        'Content-Type': 'application/json',
                                                        'Authorization': token
                                                    },
                                                    resolveWithFullResponse: true
                                                };
                                                //Create Developer in Edge
                                                grunt.log.ok("Posting Developer Details to Edge Using URL: " + developerEdgeUrl);
                                                await request(developerPostEdgeOptions)
                                                    .then(async function (developerEdgeResponse) {
                                                        if (developerEdgeResponse.statusCode == 201) {
                                                            recoverDeveloperCount++;
                                                            grunt.log.ok("developer : " + developerEmail + " has been Recovered.");
                                                        }
                                                    }).catch((error) => {
                                                        //Error occurred while Creating Developer in Edge
                                                        if (error.statusCode == 401) {
                                                            grunt.log.error("Error occurred while adding Developer to Edge due to invalid credentials. " + error);
                                                        } else if (error.statusCode == 400) {
                                                            grunt.log.error("Error occurred while adding Developer to Edge. " + error);
                                                        } else if (error.statusCode == 409) {
                                                            grunt.log.error("Error occurred while adding Developer as the Developer already exists. " + error);
                                                        } else {
                                                            grunt.log.error("Unknown Error occurred while adding Developer. " + error);
                                                        }
                                                    })
                                            } else {
                                                //Non 200 HTTP status code received.
                                                grunt.log.error("Non 200 HTTP status code  received retrieving Developer Details. " + error);
                                            }
                                        })
                                        .catch((error) => {
                                            grunt.log.error("Error occurred while retrieveing Developer Details from the Database. " + error);
                                        })
                                }
                                grunt.log.ok(recoverDeveloperCount + " out of " + developerIds.length + " Developers have been recovered.");
                                grunt.log.ok("Completed Task : recoverDevelopers");
                            }
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received while retrieving Developer Ids from the Database. " + error);
                        }
                    });
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            })
    });

    grunt.registerMultiTask('recoverDeveloper', 'Restore single Developer to org ', async function () {
        var org = grunt.option('apigee_org') || "fei-sidgs";
        var fromOrg = grunt.option('apigee_fromorg') || org;
        var version = grunt.option('backup_version') || "1.0.0-DEFAULT"
        var resourceName = grunt.option('res_name') || "Marty.Payne@Ferguson.com"

        var dbUrl = apigee.db.url;
        var edgeUrl = apigee.to.url;

        var done = this.async();
        grunt.log.ok("Started Task : recoverDeveloper");
        await OauthService.getToken()
            .then(async function (token) {
                return (token);
            })
            .then(async function (token) {
                //Get Token for Backup API Service
                var backupApiToken = "";
                if (apigee.db.account) {
                    backupApiToken = await backupApiTokenService.getBackupServiceToken();
                }

                var developerIdsUrl = dbUrl + "/edge/org/" + fromOrg + "/conf/developer/version/" + version + "/name/" + resourceName;
                var developerIdOptions = {
                    'url': developerIdsUrl,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Authorization': backupApiToken
                    },
                    resolveWithFullResponse: true
                };
                grunt.log.ok("Retrieving ID from the database for the Developer using URL: " + developerIdsUrl);
                await request(developerIdOptions)
                    .then(async function (developerIdResponse) {
                        if (developerIdResponse.statusCode == 200) {
                            var id = developerIdResponse.body
                            //Call Developerdetails
                            developerIdOptions.url = dbUrl + "/edge/conf/id/" + id;
                            grunt.log.ok("Retrieving Developer Details from the Database Using URL: " + developerIdOptions.url);
                            await request(developerIdOptions)
                                .then(async function (developerDetailsResponse) {
                                    if (developerDetailsResponse.statusCode == 200) {
                                        var developerDetail = JSON.parse(developerDetailsResponse.body);
                                        // post to edge
                                        var b64EncdDeveloperPayload = developerDetail["base64-encoded-payload"];
                                        var buff = Buffer.from(b64EncdDeveloperPayload, 'base64');
                                        let b64DecdDeveloperPayload = JSON.parse(buff.toString('utf-8'));
                                        var developerEmail = b64DecdDeveloperPayload["email"];
                                        var developerEdgeUrl = edgeUrl + "v1/organizations/" + org + "/developers";

                                        var developerEdgeOptions = {
                                            'url': developerEdgeUrl,
                                            'body': JSON.stringify(b64DecdDeveloperPayload),
                                            'method': 'POST',
                                            'headers': {
                                                'Content-Type': 'application/json',
                                                'Authorization': token
                                            },
                                            resolveWithFullResponse: true
                                        };
                                        grunt.log.ok("Posting Developer Details to Edge using the URL: " + developerEdgeUrl);
                                        await request(developerEdgeOptions)
                                            .then(async function (developerEdgeResponse) {
                                                if (developerEdgeResponse.statusCode == 201) {
                                                    grunt.log.ok("developer: " + developerEmail + " has been recovered.");
                                                    grunt.log.ok("Completed Task : recoverDeveloper");
                                                    Promise.resolve(developerEdgeResponse.body);
                                                }
                                            })
                                            .catch((error) => {
                                                //Error occurred while Creating Developer in Edge
                                                if (error.statusCode == 401) {
                                                    grunt.log.error("Error occurred while adding Developer to Edge due to invalid credentials. " + error);
                                                } else if (error.statusCode == 400) {
                                                    grunt.log.error("Error occurred while adding Developer to Edge. " + error);
                                                } else if (error.statusCode == 409) {
                                                    grunt.log.error("Error occurred while adding Developer as the Developer already exists. " + error);
                                                } else {
                                                    grunt.log.error("Unknown Error occurred while adding Developer. " + error);
                                                }
                                            })

                                    } else {
                                        //Non 200 HTTP status code received.
                                        grunt.log.error("Non 200 HTTP status code received while retrieving Developer Details from the Database. " + error);
                                    }
                                })
                                .catch((error) => {
                                    grunt.log.error("Error occurred while retrieveing Developer Details for the ID: " + id + " " + error);
                                })
                        } else {
                            //Non 200 HTTP status code received.
                            grunt.log.error("Non 200 HTTP status code  received retrieving Developer Id for developer: " + resourceName + " " + error);
                        }
                    })
                    .catch((error) => {
                        grunt.log.error("Error occurred while retrieveing Id from the database for developer- " + resourceName + " " + error);
                    })
            })
            .catch((error) => {
                //Error occured while getting Token
                grunt.log.error("Error occured while getting Token. " + error);
                Promise.resolve(error);
            })
    });
};