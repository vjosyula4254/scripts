/*jslint node: true */
var request = require('request-promise');
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);
var async = require('async');
const OauthService = require('./oauthServiceForFromOrg');
const backupApiTokenService = require('./backapiTokenService');


module.exports = function (grunt) {
	'use strict';
	grunt.registerTask('backupCompanyApps', 'Backup all company apps from org ', async function () {
		var org = grunt.option('apigee_org') || "ferguson-api";
		var version = grunt.option('backup_version') || "1.0.0-DEFAULT"

		var edgeUrl = apigee.from.url;
		var dbUrl = apigee.db.url;

		var doneCount = 0;
		var companyCount = 0;
		var bckdUpCompanyAppsCount = 0
		var totalCompanyAppsCount = 0;

		var apigeeCompaniesUrl = edgeUrl + "/v1/organizations/" + org + "/companies";

		var done = this.async();

		var backupCompanyApp = async function (companyName) {
			var apigeeCompanyAppsUrl = apigeeCompaniesUrl + "/" + companyName + "/apps?expand=true";
			//Build Options to get All Apps for a Company
			var optionsCompanyAppsUrl = {
				'url': apigeeCompanyAppsUrl,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};

			//Get all Apps for a Company
			grunt.log.ok("Getting All Apps for a Comapany using : " + apigeeCompanyAppsUrl);
			try {
				let companyAllAppsResponse = await request(optionsCompanyAppsUrl);
				if (companyAllAppsResponse.statusCode == 200) {
					var companyAppsBody = JSON.parse(companyAllAppsResponse.body);
					var companyApps = companyAppsBody.app;
					if (companyApps.length > 0) {
						totalCompanyAppsCount += companyApps.length;
						var totalAppsForCompany = 0;
						for (var j = 0; j < companyApps.length; j++) {
							var companyApp = companyApps[j];
							/*  Below code is needed to handle the scenario if there are same Company App names 
								for multiple companies. This needs to be reverted back in recoverCompanyApps
							*/
							companyApp["name"] = companyApp["companyName"] + ":" + companyApp["name"];

							var postDbUrl = dbUrl + "/edge/org/" + org + "/conf/company-app/version/" + version
							var postDbOptions = {
								'url': postDbUrl,
								'body': JSON.stringify(companyApp),
								'method': 'POST',
								'headers': {
									'Content-Type': 'application/json',
									'Authorization': backupApiToken
								},
								resolveWithFullResponse: true
							};
							try {
								grunt.log.ok("Backing up Company Apps using : " + postDbOptions.url);
								let backupApiResponse = await request(postDbOptions);
								if (backupApiResponse.statusCode == 200) {
									grunt.log.ok('Posting of the Data to the Database Completed : ' + backupApiResponse.body);
									bckdUpCompanyAppsCount++;
									totalAppsForCompany++;
								} else {
									//Recieved NON 200 status code while Backing up Company App Details into the database
									grunt.log.error("Error while Backing up Company App Details into the databse. statusCode : " + backupApiResponse.statusCode + " Error: " + backupApiResponse.error);
								}
							} catch (error) {
								//Error occurred while Backing up Company App Details into the database
								grunt.log.error("Error while Backing up Company App Details into the databse. status code :" + error + " error : " + error.error);
							}
						};
						grunt.log.ok('Backed up ' + totalAppsForCompany + ' Company App(s) for Company: ' + companyApp.companyName);
					} else {
						grunt.log.ok('No Company Apps found to backup.  companyApps : ' + JSON.stringify(companyApps));
					}
				} else {
					//Recieved NON 200 status code retrieving Company Apps
					grunt.log.error("Recieved NON 200 status code while retrieving Company Apps. StatusCode: " + companyAllAppsResponse.statusCode + ", Error : " + companyAllAppsResponse.body);
				}
				doneCount++;
				if (doneCount == companyCount) {
					grunt.log.ok('Backed up ' + bckdUpCompanyAppsCount + ' Company App(s) out of ' + totalCompanyAppsCount + ' Company Apps');
					// Completed backupCompanyApps Task
					grunt.log.ok("Completed Task : backupCompanyApps");
				}
			} catch (error) {
				//Error Getting All Company Apps
				grunt.log.error("Error occurred in backupCompanyApps Task " + error);
			}
		}

		var backupAllCompanyApps = async function (startCompanyName) {
			var apigeeCompaniesUrlWithStartkey = apigeeCompaniesUrl;
			if (startCompanyName) {
				apigeeCompaniesUrlWithStartkey += "?startKey=" + encodeURIComponent(startCompanyName);
			}
			//Build Options to get All Companies
			var companiesOptions = {
				'url': apigeeCompaniesUrlWithStartkey,
				'headers': {
					'Authorization': token,
				},
				resolveWithFullResponse: true
			};
			//Get all Companies
			grunt.log.ok("Getting All Companies using : " + apigeeCompaniesUrlWithStartkey);
			try {
				let companiesRespose = await request(companiesOptions);
				if (companiesRespose.statusCode = 200) {
					//Companies retrieved
					var companies = JSON.parse(companiesRespose.body);
					if (companies.length > 0) {
						if (startCompanyName) {
							/*	APIGEE SaaS MGMT APIs returns only 1000 companies in one management call
								this is to check if backupAllCompanies called recursively ( for more than 1000 companies),
								if that's the case then startCompanyName will have the company which we provided
								as a startKey, so we should not process the first Company from this list. Remove first Company.
							*/
							//Remove first company from the list.
							grunt.log.ok("removing " + companies[0] + "form the list");
							companies.shift();
						}

						// Process remaining Companies
						if (companies.length > 0) {
							companyCount += companies.length

							for (var companyIndex = 0; companyIndex < companies.length; companyIndex++) {
								grunt.log.ok("Backing up All Company Apps for the Company : " + companies[companyIndex]);
								await backupCompanyApp(companies[companyIndex]);
							}

							/* 	APIGEE cloud returns only 1000 companies in one management call
								If number of Companies are >=1000   then there is possibility that there
								are more companies. Make a recursive call to get all the companies 
								until all companies are retrieved.
							*/
							if (companies.length >= 999) {
								lastCompany = companies[companies.length - 1];
								await backupAllCompanyApps(lastCompany);
							}
						}

					}
				} else {
					//Received non 200 HTTP call from retrieve companies
					grunt.log.error("Error while retrieving Companies " + error);
				}
			} catch (error) {
				//Error occured while retrieving Company Apps
				grunt.log.error("Error occured while retrieving All Companies. " + error);
			}
		}

		// Start backupCompanyApps Task
		grunt.log.ok("Started Task : backupCompanyApps");
		try {
			//Get Token
			var token = await OauthService.getToken();

			//Get Token for Backup API Service
			var backupApiToken = "";
			if (apigee.db.account) {
				backupApiToken = await backupApiTokenService.getBackupServiceToken();
				//console.log(backupApiToken);
			}

			//Backup all CompanyApps
			await backupAllCompanyApps(null);
		} catch (error) {
			//Error occured while doing backupCompanyApps Task
			grunt.log.error("Error occured while doing backupCompanyApps Task. " + error);
		}
	});
};