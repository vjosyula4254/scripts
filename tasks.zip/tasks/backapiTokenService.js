var { google } = require('googleapis')
var env = process.env.NODE_ENV || 'dev';
var apigee = require('../config-' + env);



module.exports.getBackupServiceToken = async function getBackupServiceToken() {
    'use strict';
    return new Promise((resolve, reject) => {

        let privatekey = require(`./resources/${apigee.db.account}`)
        let audience = apigee.db.url;

        let jwtClient = new google.auth.JWT(
            privatekey.client_email,
            null,
            privatekey.private_key,
            audience
        )

        jwtClient.authorize(function (err, body) {

            if (!err) {
                let idToken = "Bearer" + " " + body.id_token;
                resolve(idToken);
            } else {
                reject(new Error('Unable to generate Backup API id token'));
            }
        });

    })


}

/*
//Test getBackupServiceToken
async function testGetBackupServiceToken() {
    const backupApiTokenService = require('./backapiTokenService');
    try {
        var token = await backupApiTokenService.getBackupServiceToken();
        console.log(token)

    } catch (error) {
        console.log(error);
    }
}

try {
    testGetBackupServiceToken();
} catch (error) {
    console.log(error);
}
*/